import { cn } from "@/lib/utils";

export function OmniSeal({
  className,
  live = false,
}: {
  className?: string;
  live?: boolean;
}) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={cn("text-primary", live && "seal-live", className)}
      aria-hidden
    >
      <circle cx="32" cy="32" r="30" fill="none" stroke="currentColor" strokeOpacity="0.35" strokeWidth="1" />
      <circle cx="32" cy="32" r="22" fill="none" stroke="currentColor" strokeOpacity="0.5" strokeWidth="0.8" />
      <path
        d="M32 6 L35 24 L32 22 L29 24 Z M58 32 L40 35 L42 32 L40 29 Z M32 58 L29 40 L32 42 L35 40 Z M6 32 L24 29 L22 32 L24 35 Z"
        fill="currentColor"
      />
      <circle cx="32" cy="32" r="3.2" fill="currentColor" />
    </svg>
  );
}

export function PresidentSeal({ className, live = false }: { className?: string; live?: boolean }) {
  return (
    <svg viewBox="0 0 64 64" className={cn(live ? "text-destructive seal-live" : "text-muted", className)} aria-hidden>
      <rect x="10" y="14" width="44" height="36" rx="4" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="32" cy="32" r="8" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="32" cy="32" r="2.5" fill="currentColor" />
      <path d="M22 50 L32 44 L42 50" fill="none" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}

export function MvsSeal({ className, live = false }: { className?: string; live?: boolean }) {
  return (
    <svg viewBox="0 0 64 64" className={cn(live ? "text-primary seal-live" : "text-muted", className)} aria-hidden>
      <circle cx="32" cy="32" r="20" fill="none" stroke="currentColor" strokeWidth="1.4" strokeDasharray="4 3" />
      <path d="M18 32 H46 M32 18 V46" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="32" cy="32" r="4" fill="none" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}
