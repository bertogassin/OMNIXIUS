import { useEffect, useMemo, useState } from "react";
import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  Boxes,
  Compass,
  Database,
  Eye,
  Fingerprint,
  LayoutGrid,
  Menu,
  MessagesSquare,
  PenLine,
  Radio,
  Search,
  Shield,
  Store,
  Wallet,
} from "lucide-react";
import { Toaster, toast } from "sonner";
import { OmniSeal, MvsSeal, PresidentSeal } from "@/components/seal";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { copy } from "@/lib/i18n";
import { bearingTo } from "@/lib/format";
import { HOME, cities, experts, guards, listings } from "@/lib/seed";
import { openThreats, usePlatform } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", key: "deck" as const, icon: LayoutGrid, group: "deck" },
  { to: "/map", key: "map" as const, icon: Compass, group: "field" },
  { to: "/agora", key: "agora" as const, icon: Store, group: "field" },
  { to: "/guardio", key: "guardio" as const, icon: Shield, group: "field" },
  { to: "/vault", key: "vault" as const, icon: Wallet, group: "capital" },
  { to: "/chain", key: "chain" as const, icon: Boxes, group: "capital" },
  { to: "/repo", key: "repo" as const, icon: Database, group: "capital" },
  { to: "/nexus", key: "nexus" as const, icon: Radio, group: "people" },
  { to: "/passport", key: "passport" as const, icon: Fingerprint, group: "people" },
  { to: "/notepad", key: "notepad" as const, icon: PenLine, group: "intel" },
  { to: "/mvs", key: "mvs" as const, icon: MessagesSquare, group: "intel" },
  { to: "/president", key: "president" as const, icon: Eye, group: "intel" },
];

const PRIMARY = ["/", "/map", "/agora", "/guardio"];

export function AppShell() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const hydrated = usePlatform((s) => s.hydrated);
  const bootSeen = usePlatform((s) => s.bootSeen);
  const hydrate = usePlatform((s) => s.hydrate);
  const tickChain = usePlatform((s) => s.tickChain);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    const id = window.setInterval(() => tickChain(), 8000);
    return () => window.clearInterval(id);
  }, [tickChain]);

  if (!hydrated) {
    return <BootScreen force />;
  }
  if (!bootSeen) {
    return <BootScreen />;
  }

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-card focus:px-3 focus:py-2"
      >
        Skip
      </a>
      <div className="mx-auto flex min-h-dvh max-w-[1440px]">
        <DesktopNav t={t} />
        <div className="flex min-w-0 flex-1 flex-col">
          <TopBar t={t} />
          <main id="main" className="flex-1 px-4 py-5 pb-28 sm:px-6 lg:px-8 lg:pb-8">
            <Outlet />
          </main>
        </div>
      </div>
      <MobileNav t={t} />
      <CompassFab t={t} />
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          className: "!bg-card !text-foreground !border-border !shadow-[var(--shadow-border)]",
        }}
      />
    </div>
  );
}

function BootScreen({ force }: { force?: boolean }) {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const setBootSeen = usePlatform((s) => s.setBootSeen);
  const setLocale = usePlatform((s) => s.setLocale);

  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-background px-6 text-center">
      <div className="boot-stagger flex max-w-md flex-col items-center">
        <OmniSeal className="size-16" live />
        <p className="type-kicker mt-8">{t.kicker}</p>
        <h1 className="mt-3 font-display text-5xl font-medium tracking-tight sm:text-6xl">{t.app}</h1>
        <p className="mt-4 text-sm text-muted">{t.bootA}</p>
        <p className="mt-1 text-xs text-subtle">{t.bootB}</p>
        <p className="mt-8 max-w-sm text-sm leading-relaxed text-muted">{t.watchword}</p>
        {!force ? (
          <div className="mt-10 flex flex-wrap items-center justify-center gap-2">
            <Button onClick={() => setBootSeen()}>{t.enter}</Button>
            <Button variant="ghost" onClick={() => setLocale(locale === "ru" ? "en" : "ru")}>
              {t.lang}
            </Button>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function TopBar({ t }: { t: ReturnType<typeof copy> }) {
  const setLocale = usePlatform((s) => s.setLocale);
  const locale = usePlatform((s) => s.locale);
  const passport = usePlatform((s) => s.passport);
  const threats = usePlatform((s) => openThreats(s).length);
  const [cmd, setCmd] = useState(false);
  const [more, setMore] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCmd(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b border-border bg-background/90 px-4 backdrop-blur-sm sm:px-6">
      <Link to="/" className="flex items-center gap-2 lg:hidden">
        <OmniSeal className="size-7" />
        <span className="font-display text-lg tracking-tight">OMNIXIUS</span>
      </Link>
      <button
        type="button"
        onClick={() => setCmd(true)}
        className="ml-auto hidden h-10 min-w-48 items-center gap-2 rounded-md bg-secondary px-3 text-left text-sm text-muted shadow-[var(--shadow-border)] md:flex"
      >
        <Search className="size-4" />
        {t.search}
        <span className="ml-auto text-xs tracking-wide text-subtle">{t.commandHint}</span>
      </button>
      <Button variant="ghost" size="icon" className="ml-auto md:hidden" onClick={() => setCmd(true)} aria-label={t.search}>
        <Search className="size-4" />
      </Button>
      <Button variant="ghost" size="sm" onClick={() => setLocale(locale === "ru" ? "en" : "ru")}>
        {t.lang}
      </Button>
      <SosButton t={t} />
      <Link
        to="/passport"
        className="hidden h-10 items-center gap-2 rounded-md px-2 text-xs text-muted hover:bg-secondary sm:flex"
      >
        <span className="tabular-nums text-foreground">{passport.trust}</span>
        <span>{passport.clearance === "operator" ? t.operator : passport.clearance === "pro" ? t.pro : t.citizen}</span>
        {threats > 0 ? <span className="size-1.5 rounded-full bg-destructive pulse-dot" /> : null}
      </Link>
      <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMore(true)} aria-label={t.more}>
        <Menu className="size-4" />
      </Button>
      <CommandDialog open={cmd} onOpenChange={setCmd} t={t} />
      <Sheet open={more} onOpenChange={setMore} >
        <SheetContent side="bottom" title={t.modules}>
          <nav className="mt-4 grid grid-cols-3 gap-2 pb-4">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setMore(false)}
                className="flex min-h-14 flex-col items-center justify-center gap-1 rounded-lg bg-secondary text-xs text-muted"
              >
                <n.icon className="size-4" />
                {t[n.key]}
              </Link>
            ))}
          </nav>
        </SheetContent>
      </Sheet>
    </header>
  );
}

function DesktopNav({ t }: { t: ReturnType<typeof copy> }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const threats = usePlatform((s) => openThreats(s).length);
  const groups = [
    { id: "deck", label: t.deck },
    { id: "field", label: t.field },
    { id: "capital", label: t.capital },
    { id: "people", label: t.people },
    { id: "intel", label: t.intel },
  ];
  return (
    <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-3 py-5 lg:flex">
      <Link to="/" className="mb-8 flex items-center gap-2 px-2">
        <OmniSeal className="size-8" />
        <span className="font-display text-xl tracking-tight">OMNIXIUS</span>
      </Link>
      <nav className="flex flex-1 flex-col gap-5 overflow-y-auto">
        {groups.map((g) => (
          <div key={g.id}>
            {g.id !== "deck" ? <p className="type-kicker mb-2 px-2">{g.label}</p> : null}
            <ul className="space-y-0.5">
              {NAV.filter((n) => n.group === g.id).map((n) => {
                const on = pathname === n.to;
                return (
                  <li key={n.to}>
                    <Link
                      to={n.to}
                      className={cn(
                        "flex h-11 items-center gap-2 rounded-md px-2 text-sm transition-colors duration-150",
                        on ? "bg-secondary text-foreground" : "text-muted hover:bg-secondary/60 hover:text-foreground",
                      )}
                    >
                      <n.icon className="size-4" />
                      {t[n.key]}
                      {n.key === "president" && threats > 0 ? (
                        <span className="ml-auto size-1.5 rounded-full bg-destructive pulse-dot" />
                      ) : null}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
      <div className="mt-4 flex items-center gap-3 px-2">
        <PresidentSeal className="size-8" live={threats > 0} />
        <MvsSeal className="size-8" live />
      </div>
    </aside>
  );
}

function MobileNav({ t }: { t: ReturnType<typeof copy> }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = NAV.filter((n) => PRIMARY.includes(n.to));
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 px-2 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm lg:hidden">
      <ul className="mx-auto flex h-16 max-w-lg items-stretch">
        {items.map((n) => {
          const on = pathname === n.to;
          return (
            <li key={n.to} className="flex-1">
              <Link
                to={n.to}
                className={cn(
                  "flex h-full min-h-11 flex-col items-center justify-center gap-1 text-[0.6875rem] tracking-wide",
                  on ? "text-foreground" : "text-muted",
                )}
              >
                <n.icon className="size-4" />
                {t[n.key]}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

function SosButton({ t }: { t: ReturnType<typeof copy> }) {
  const dispatchGuard = usePlatform((s) => s.dispatchGuard);
  const cityId = usePlatform((s) => s.selectedCityId) ?? "zurich";
  const onSos = () => {
    const local = guards.filter((g) => g.cityId === cityId && g.available);
    const g = (local[0] ?? guards[0])!;
    const res = dispatchGuard(g.id, true);
    if (res.ok) toast.success(t.sosSent);
    else toast.error(t.needClearance);
  };
  return (
    <Button variant="danger" size="sm" onClick={onSos}>
      {t.sos}
    </Button>
  );
}

function CompassFab({ t }: { t: ReturnType<typeof copy> }) {
  const cityId = usePlatform((s) => s.selectedCityId);
  const city = cities.find((c) => c.id === cityId);
  const deg = city ? bearingTo(HOME, city) : 0;
  return (
    <Link
      to="/map"
      aria-label={t.compass}
      className="fixed right-4 bottom-20 z-20 hidden size-16 items-center justify-center rounded-full bg-card shadow-[var(--shadow-border-hover)] sm:flex lg:bottom-6"
    >
      <svg viewBox="0 0 80 80" className="size-14 text-primary">
        <g className="compass-ring">
          <circle cx="40" cy="40" r="34" fill="none" stroke="currentColor" strokeOpacity="0.35" />
          {Array.from({ length: 12 }, (_, i) => {
            const a = (i * 30 * Math.PI) / 180;
            const x1 = 40 + Math.cos(a) * 28;
            const y1 = 40 + Math.sin(a) * 28;
            const x2 = 40 + Math.cos(a) * 32;
            const y2 = 40 + Math.sin(a) * 32;
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="currentColor" strokeWidth="1" />;
          })}
        </g>
        <g style={{ transform: `rotate(${deg}deg)`, transformOrigin: "40px 40px" }}>
          <polygon points="40,14 44,40 40,36 36,40" fill="currentColor" />
          <polygon points="40,66 36,40 40,44 44,40" fill="currentColor" fillOpacity="0.35" />
        </g>
      </svg>
      <span className="sr-only">{city ? `${t.dest} ${city.name}` : t.noDest}</span>
    </Link>
  );
}

function CommandDialog({
  open,
  onOpenChange,
  t,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  t: ReturnType<typeof copy>;
}) {
  const [q, setQ] = useState("");
  const locale = usePlatform((s) => s.locale);
  const items = useMemo(() => {
    const s = q.trim().toLowerCase();
    const mods = NAV.map((n) => ({
      id: n.to,
      to: n.to,
      label: t[n.key],
      hint: t.modules,
    }));
    const people = experts.map((e) => ({
      id: e.id,
      to: "/map" as const,
      label: e.name,
      hint: locale === "ru" ? e.craftRu : e.craft,
    }));
    const lots = listings.map((l) => ({
      id: l.id,
      to: "/agora" as const,
      label: locale === "ru" ? l.titleRu : l.title,
      hint: t.listings,
    }));
    const all = [...mods, ...people, ...lots];
    if (!s) return all.slice(0, 12);
    return all.filter((i) => `${i.label} ${i.hint}`.toLowerCase().includes(s)).slice(0, 16);
  }, [q, t, locale]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent title={t.search} className="p-4">
        <Input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t.search}
          className="mt-3"
        />
        <ul className="mt-3 max-h-80 overflow-y-auto">
          {items.length === 0 ? (
            <li className="px-2 py-6 text-center text-sm text-muted">{t.noResults}</li>
          ) : (
            items.map((i) => (
              <li key={i.id}>
                <Link
                  to={i.to}
                  onClick={() => onOpenChange(false)}
                  className="flex min-h-11 items-center justify-between rounded-md px-2 text-sm hover:bg-secondary"
                >
                  <span>{i.label}</span>
                  <span className="text-xs text-muted">{i.hint}</span>
                </Link>
              </li>
            ))
          )}
        </ul>
      </DialogContent>
    </Dialog>
  );
}
