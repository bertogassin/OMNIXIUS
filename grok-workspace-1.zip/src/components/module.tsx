import type { ReactNode } from "react";
import { Badge } from "@/components/ui/badge";
import type { T } from "@/lib/i18n";
import type { Verification } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ModuleHeader({
  kicker,
  title,
  lede,
  actions,
}: {
  kicker: string;
  title: string;
  lede: string;
  actions?: ReactNode;
}) {
  return (
    <header className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        <p className="type-kicker">{kicker}</p>
        <h1 className="mt-2 font-display text-3xl font-medium tracking-tight text-foreground sm:text-4xl">
          {title}
        </h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted">{lede}</p>
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}

export function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: ReactNode;
  hint?: string;
}) {
  return (
    <div className="panel rounded-xl p-4">
      <p className="type-kicker">{label}</p>
      <p className="mt-2 font-display text-2xl tabular-nums tracking-tight">{value}</p>
      {hint ? <p className="mt-1 text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

export function VerifBadge({ v, t }: { v: Verification; t: T }) {
  if (v === "credential") return <Badge tone="success">{t.verified}</Badge>;
  if (v === "identity") return <Badge tone="warn">{t.identity}</Badge>;
  return <Badge tone="muted">{t.unverified}</Badge>;
}

export function Panel({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return <section className={cn("panel rounded-xl p-4 sm:p-5", className)}>{children}</section>;
}
