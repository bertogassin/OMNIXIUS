import { cn } from "@/lib/utils";

export function Segmented({
  value,
  onChange,
  options,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { id: string; label: string }[];
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-wrap gap-1 rounded-lg bg-secondary p-1",
        className,
      )}
      role="tablist"
    >
      {options.map((o) => {
        const on = o.id === value;
        return (
          <button
            key={o.id}
            type="button"
            role="tab"
            aria-selected={on}
            onClick={() => onChange(o.id)}
            className={cn(
              "h-9 min-h-9 rounded-md px-3 text-xs font-medium tracking-wide transition-colors duration-150",
              on ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted hover:text-foreground",
            )}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
