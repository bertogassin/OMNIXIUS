import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "default",
  children,
}: {
  className?: string;
  tone?: "default" | "success" | "danger" | "warn" | "muted";
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-sm px-1.5 py-0.5 text-[0.6875rem] font-medium tracking-wide uppercase",
        tone === "default" && "bg-secondary text-primary",
        tone === "success" && "bg-success/15 text-success",
        tone === "danger" && "bg-destructive/15 text-destructive",
        tone === "warn" && "bg-warn/15 text-warn",
        tone === "muted" && "bg-secondary text-muted",
        className,
      )}
    >
      {children}
    </span>
  );
}
