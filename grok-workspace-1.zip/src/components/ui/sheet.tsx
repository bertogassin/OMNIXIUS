import type { ReactNode } from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

export const Sheet = DialogPrimitive.Root;
export const SheetTrigger = DialogPrimitive.Trigger;

export function SheetContent({
  className,
  children,
  side = "right",
  title,
}: {
  className?: string;
  children: ReactNode;
  side?: "right" | "bottom" | "left";
  title?: string;
}) {
  return (
    <DialogPrimitive.Portal>
      <DialogPrimitive.Overlay className="fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0" />
      <DialogPrimitive.Content
        className={cn(
          "fixed z-50 bg-card shadow-[var(--shadow-border-hover)]",
          side === "right" && "inset-y-0 right-0 h-full w-[min(100%,22rem)] rounded-l-xl p-5",
          side === "left" && "inset-y-0 left-0 h-full w-[min(100%,18rem)] rounded-r-xl p-5",
          side === "bottom" && "inset-x-0 bottom-0 max-h-[80vh] rounded-t-xl p-5",
          className,
        )}
      >
        {title ? (
          <DialogPrimitive.Title className="font-display text-lg">{title}</DialogPrimitive.Title>
        ) : (
          <DialogPrimitive.Title className="sr-only">Panel</DialogPrimitive.Title>
        )}
        {children}
        <DialogPrimitive.Close className="absolute top-3 right-3 size-11 text-muted hover:text-foreground">
          <X className="mx-auto size-4" />
        </DialogPrimitive.Close>
      </DialogPrimitive.Content>
    </DialogPrimitive.Portal>
  );
}
