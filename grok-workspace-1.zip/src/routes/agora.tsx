import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Segmented } from "@/components/ui/tabs";
import { copy } from "@/lib/i18n";
import { oxi } from "@/lib/format";
import { cities } from "@/lib/seed";
import { mergeListings, cityName, usePlatform } from "@/lib/store";
import type { ListingKind } from "@/lib/types";

export const Route = createFileRoute("/agora")({ component: Agora });

function Agora() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const kind = usePlatform((s) => s.listingKind);
  const setListingKind = usePlatform((s) => s.setListingKind);
  const extraListings = usePlatform((s) => s.extraListings);
  const lots = mergeListings(extraListings).filter((l) => kind === "all" || l.kind === kind);
  const lockListing = usePlatform((s) => s.lockListing);
  const addListing = usePlatform((s) => s.addListing);
  const setSelectedCity = usePlatform((s) => s.setSelectedCity);
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("400");
  const [cityId, setCityId] = useState("zurich");
  const [lotKind, setLotKind] = useState<ListingKind>("goods");
  const [hidden, setHidden] = useState(false);

  return (
    <div>
      <ModuleHeader kicker={t.field} title={t.agora} lede={t.agoraLede} />
      <Segmented
        value={kind}
        onChange={(id) => setListingKind(id as typeof kind)}
        options={[
          { id: "all", label: t.all },
          { id: "goods", label: t.goods },
          { id: "land", label: t.land },
          { id: "auto", label: t.auto },
          { id: "service", label: t.service },
        ]}
      />
      <ul className="mt-4 grid gap-3 sm:grid-cols-2">
        {lots.map((l) => (
          <li key={l.id}>
            <Panel>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium">{locale === "ru" ? l.titleRu : l.title}</p>
                  <p className="text-xs text-muted">
                    {t[l.kind]} · {cityName(l.cityId)} · {l.seller}
                  </p>
                </div>
                {l.hiddenRoute ? <Badge>{t.hidden}</Badge> : null}
              </div>
              <p className="mt-2 text-sm text-muted">{locale === "ru" ? l.blurbRu : l.blurb}</p>
              <p className="mt-3 font-display text-2xl tabular-nums">
                {oxi(l.priceOxi, 0)} <span className="text-sm text-muted">{t.oxi}</span>
              </p>
              <div className="mt-4 flex gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    const res = lockListing(l.id);
                    if (res.ok) {
                      toast.success(res.free ? t.firstFree : t.lockedOk);
                      setSelectedCity(l.cityId);
                    } else toast.error(t.needClearance);
                  }}
                >
                  {l.kind === "land" ? t.lease : t.buy}
                </Button>
              </div>
            </Panel>
          </li>
        ))}
      </ul>
      <Panel className="mt-6">
        <p className="type-kicker">{t.newListing}</p>
        <form
          className="mt-4 grid gap-3 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            const res = addListing({
              title: title.trim(),
              kind: lotKind,
              priceOxi: Number(price) || 0,
              cityId,
              hiddenRoute: hidden,
            });
            if (!res.ok) toast.error(t.offerBlocked);
            else {
              toast.success(t.posted);
              setTitle("");
            }
          }}
        >
          <div className="sm:col-span-2">
            <Label htmlFor="lot-title">{t.title}</Label>
            <Input id="lot-title" className="mt-1" value={title} onChange={(e) => setTitle(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="lot-price">{t.price}</Label>
            <Input id="lot-price" className="mt-1" type="number" min={1} value={price} onChange={(e) => setPrice(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="lot-city">{t.city}</Label>
            <select
              id="lot-city"
              className="mt-1 h-11 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]"
              value={cityId}
              onChange={(e) => setCityId(e.target.value)}
            >
              {cities.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label>{t.kind}</Label>
            <select
              className="mt-1 h-11 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]"
              value={lotKind}
              onChange={(e) => setLotKind(e.target.value as ListingKind)}
            >
              <option value="goods">{t.goods}</option>
              <option value="land">{t.land}</option>
              <option value="auto">{t.auto}</option>
              <option value="service">{t.service}</option>
            </select>
          </div>
          <label className="flex h-11 items-center gap-2 text-sm">
            <input type="checkbox" checked={hidden} onChange={(e) => setHidden(e.target.checked)} />
            {t.confidential}
          </label>
          <div className="sm:col-span-2">
            <Button type="submit">{t.publishLot}</Button>
          </div>
        </form>
      </Panel>
    </div>
  );
}
