import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel, Stat, VerifBadge } from "@/components/module";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Segmented } from "@/components/ui/tabs";
import { copy } from "@/lib/i18n";
import { oxi } from "@/lib/format";
import { usePlatform } from "@/lib/store";
import type { Clearance, Verification } from "@/lib/types";

export const Route = createFileRoute("/passport")({ component: Passport });

function Passport() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const p = usePlatform((s) => s.passport);
  const contracts = usePlatform((s) => s.contracts);
  const setPassport = usePlatform((s) => s.setPassport);
  const setClearance = usePlatform((s) => s.setClearance);
  const setVerification = usePlatform((s) => s.setVerification);
  const resetDemo = usePlatform((s) => s.resetDemo);
  const [name, setName] = useState(p.name);
  const [handle, setHandle] = useState(p.handle);

  return (
    <div>
      <ModuleHeader kicker={t.people} title={t.passport} lede={t.passLede} />
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label={t.trust} value={p.trust} />
        <Stat label={t.oxi} value={oxi(p.oxi, 0)} />
        <Stat label={t.contracts} value={contracts.length} />
      </div>
      <Panel className="mt-4">
        <p className="type-kicker">{t.lattice}</p>
        <p className="mt-2 text-sm text-muted">{t.latticeCopy}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <VerifBadge v={p.verification} t={t} />
          <Badge>{p.clearance === "operator" ? t.operatorLong : p.clearance === "pro" ? t.proLong : t.citizenLong}</Badge>
          {p.hasTools ? <Badge tone="success">{t.withTools}</Badge> : <Badge tone="muted">{t.withoutTools}</Badge>}
        </div>
        <svg viewBox="0 0 320 120" className="mt-4 h-24 w-full text-primary" aria-hidden>
          <circle cx="40" cy="60" r="16" fill="none" stroke="currentColor" />
          <circle cx="160" cy="60" r="22" fill="none" stroke="currentColor" />
          <circle cx="280" cy="60" r="16" fill="none" stroke="currentColor" />
          <line x1="56" y1="60" x2="138" y2="60" stroke="currentColor" strokeOpacity="0.4" />
          <line x1="182" y1="60" x2="264" y2="60" stroke="currentColor" strokeOpacity="0.4" />
          <text x="40" y="100" textAnchor="middle" fill="currentColor" style={{ fontSize: 10 }}>
            BOLH
          </text>
          <text x="160" y="100" textAnchor="middle" fill="currentColor" style={{ fontSize: 10 }}>
            PASSPORT
          </text>
          <text x="280" y="100" textAnchor="middle" fill="currentColor" style={{ fontSize: 10 }}>
            VAULT
          </text>
        </svg>
      </Panel>
      <Panel className="mt-4">
        <form
          className="grid gap-3 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            setPassport({ name: name.trim() || p.name, handle: handle.replace(/^@/, "") });
            toast.success(t.saved);
          }}
        >
          <div>
            <Label htmlFor="nm">{t.name}</Label>
            <Input id="nm" className="mt-1" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="hd">{t.handle}</Label>
            <Input id="hd" className="mt-1" value={handle} onChange={(e) => setHandle(e.target.value)} />
          </div>
          <div className="sm:col-span-2">
            <p className="mb-2 text-xs text-muted">{t.operatorLong}</p>
            <Segmented
              value={p.clearance}
              onChange={(id) => setClearance(id as Clearance)}
              options={[
                { id: "citizen", label: t.citizenLong },
                { id: "pro", label: t.proLong },
                { id: "operator", label: t.operatorLong },
              ]}
            />
          </div>
          <div className="sm:col-span-2">
            <p className="mb-2 text-xs text-muted">{t.credentialLong}</p>
            <Segmented
              value={p.verification}
              onChange={(id) => setVerification(id as Verification)}
              options={[
                { id: "none", label: t.none },
                { id: "identity", label: t.identityLong },
                { id: "credential", label: t.credentialLong },
              ]}
            />
          </div>
          <label className="flex h-11 items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={p.hasTools}
              onChange={(e) => setPassport({ hasTools: e.target.checked })}
            />
            {t.youHave}
          </label>
          <div className="sm:col-span-2">
            <Button type="submit">{t.saveName}</Button>
          </div>
        </form>
      </Panel>
      <Panel className="mt-4">
        <p className="text-sm text-muted">{t.contracts}</p>
        {contracts.length === 0 ? (
          <p className="mt-2 text-sm text-muted">{t.emptyContracts}</p>
        ) : (
          <ul className="mt-3 divide-y divide-border">
            {contracts.map((c) => (
              <li key={c.id} className="flex justify-between py-2 text-sm">
                <span>{c.title}</span>
                <span className="text-muted">{t[c.status]}</span>
              </li>
            ))}
          </ul>
        )}
        <Button
          variant="outline"
          size="sm"
          className="mt-4"
          onClick={() => {
            resetDemo();
            toast.success(t.restDone);
          }}
        >
          {t.rest}
        </Button>
      </Panel>
    </div>
  );
}
