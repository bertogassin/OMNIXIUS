import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { copy } from "@/lib/i18n";
import { ago } from "@/lib/format";
import { mergePosts, cityName, usePlatform } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/nexus")({ component: Nexus });

function Nexus() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const extraPosts = usePlatform((s) => s.extraPosts);
  const posts = mergePosts(extraPosts);
  const liked = usePlatform((s) => s.liked);
  const likePost = usePlatform((s) => s.likePost);
  const addPost = usePlatform((s) => s.addPost);
  const [body, setBody] = useState("");

  return (
    <div>
      <ModuleHeader kicker={t.people} title={t.nexus} lede={t.nexusLede} />
      <Panel>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!body.trim()) return;
            addPost(body.trim());
            setBody("");
            toast.success(t.posted);
          }}
        >
          <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder={t.notePh} />
          <Button type="submit" className="mt-3" size="sm">
            {t.post}
          </Button>
        </form>
      </Panel>
      <ul className="mt-4 space-y-3">
        {posts.map((p) => {
          const on = liked.includes(p.id);
          return (
            <li key={p.id}>
              <Panel>
                <p className="text-sm leading-relaxed">{locale === "ru" ? p.bodyRu : p.body}</p>
                <div className="mt-3 flex items-center justify-between text-xs text-muted">
                  <span>
                    {p.author} · {cityName(p.cityId)} · {ago(p.ts, locale)}
                  </span>
                  <button
                    type="button"
                    onClick={() => likePost(p.id)}
                    className={cn("h-11 px-2", on && "text-primary")}
                  >
                    {t.like} {p.likes + (on ? 1 : 0)}
                  </button>
                </div>
              </Panel>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
