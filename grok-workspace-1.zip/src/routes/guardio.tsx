import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { copy } from "@/lib/i18n";
import { oxi } from "@/lib/format";
import { guards } from "@/lib/seed";
import { cityName, usePlatform } from "@/lib/store";

export const Route = createFileRoute("/guardio")({ component: Guardio });

function Guardio() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const dispatchGuard = usePlatform((s) => s.dispatchGuard);
  const allContracts = usePlatform((s) => s.contracts);
  const contracts = allContracts.filter((c) => c.kind === "guard");
  const setStatus = usePlatform((s) => s.setContractStatus);
  const [box, setBox] = useState<string | null>(null);

  return (
    <div>
      <ModuleHeader kicker={t.field} title={t.guardio} lede={t.guardLede} />
      <ul className="grid gap-3 sm:grid-cols-2">
        {guards.map((g) => (
          <li key={g.id}>
            <Panel>
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">{g.firm}</p>
                  <p className="text-xs text-muted">{cityName(g.cityId)}</p>
                </div>
                <Badge tone={g.available ? "success" : "muted"}>{g.available ? t.available : t.busy}</Badge>
              </div>
              <p className="mt-3 text-sm text-muted">
                {t.response} {g.responseMin} {t.min} · {g.units} · {g.armed ? t.armed : t.unarmed}
              </p>
              <p className="mt-1 font-display text-xl tabular-nums">
                {oxi(g.rateOxi, 0)} <span className="text-sm text-muted">{t.oxi}</span>
              </p>
              <Button
                size="sm"
                className="mt-4"
                onClick={() => {
                  const res = dispatchGuard(g.id);
                  if (res.ok) toast.success(res.free ? t.firstFree : t.dispatched);
                  else toast.error(t.needClearance);
                }}
              >
                {t.dispatch}
              </Button>
            </Panel>
          </li>
        ))}
      </ul>
      <Panel className="mt-6">
        <p className="type-kicker">{t.contracts}</p>
        {contracts.length === 0 ? (
          <p className="mt-3 text-sm text-muted">{t.emptyContracts}</p>
        ) : (
          <ul className="mt-3 divide-y divide-border">
            {contracts.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div>
                  <p className="text-sm">{c.title}</p>
                  <p className="text-xs text-muted">
                    {cityName(c.cityId)} · {oxi(c.amount, 0)} {t.oxi}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge tone={c.status === "disputed" ? "danger" : "default"}>{t[c.status]}</Badge>
                  {c.status === "in_field" || c.status === "locked" ? (
                    <Button size="sm" variant="outline" onClick={() => setBox(c.id)}>
                      {t.dispute}
                    </Button>
                  ) : null}
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
      <Dialog open={!!box} onOpenChange={(o) => !o && setBox(null)}>
        <DialogContent title={t.dispute}>
          <div className="scanlines relative mt-4 overflow-hidden rounded-lg bg-secondary p-6">
            <p className="type-kicker">{t.stream}</p>
            <p className="mt-2 font-display text-2xl">{t.onSite}</p>
            <p className="mt-2 text-sm text-muted">ZK · {t.hidden}</p>
            <div className="mt-4 h-24 rounded-md bg-background/50 shadow-[var(--shadow-border)]" />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              size="sm"
              onClick={() => {
                if (box) setStatus(box, "resolved");
                setBox(null);
              }}
            >
              {t.resolveA}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                if (box) setStatus(box, "resolved");
                setBox(null);
              }}
            >
              {t.resolveB}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
