import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { toast } from "sonner";
import { ModuleHeader, Panel, Stat } from "@/components/module";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { copy } from "@/lib/i18n";
import { isValentine, oxi } from "@/lib/format";
import { oxiSpark } from "@/lib/seed";
import { usePlatform } from "@/lib/store";
import type { ChainId } from "@/lib/types";

export const Route = createFileRoute("/vault")({ component: Vault });

function Vault() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const p = usePlatform((s) => s.passport);
  const valentineDemo = usePlatform((s) => s.valentineDemo);
  const setValentineDemo = usePlatform((s) => s.setValentineDemo);
  const sendTx = usePlatform((s) => s.sendTx);
  const [to, setTo] = useState("@nika");
  const [amount, setAmount] = useState("40");
  const [zk, setZk] = useState(true);
  const [chain, setChain] = useState<ChainId>("omni");
  const spark = oxiSpark.map((v, i) => ({ i, v }));
  const valentine = isValentine(valentineDemo);

  return (
    <div>
      <ModuleHeader
        kicker={t.capital}
        title={t.vault}
        lede={t.vaultLede}
        actions={
          <label className="flex h-11 items-center gap-2 text-xs text-muted">
            <Switch checked={valentineDemo} onCheckedChange={setValentineDemo} />
            {t.valentineOn}
          </label>
        }
      />
      {valentine ? (
        <p className="mb-5 rounded-lg bg-secondary px-4 py-3 text-sm text-primary shadow-[var(--shadow-border)]">
          {t.valentine}
        </p>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Stat label="OXI" value={oxi(p.oxi, 0)} />
        <Stat label="WBTC" value={oxi(p.wbtc, 3)} />
        <Stat label="WETH" value={oxi(p.weth, 2)} />
        <Stat label="SOL" value={oxi(p.sol, 1)} />
        <Stat label="BNB" value={oxi(p.bnb, 0)} />
      </div>
      <Panel className="mt-4">
        <p className="type-kicker">{t.spark}</p>
        <div className="mt-3 h-36">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={spark}>
              <Area type="monotone" dataKey="v" stroke="var(--color-primary)" fill="color-mix(in oklab, var(--color-primary) 22%, transparent)" strokeWidth={1.6} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Panel>
      <Panel className="mt-4">
        <p className="type-kicker">{t.send}</p>
        <form
          className="mt-4 grid gap-3 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            const res = sendTx({
              to,
              amount: Number(amount),
              asset: "OXI",
              chain,
              zk,
            });
            if (res.ok) toast.success(res.free ? t.firstFree : t.sent);
            else toast.error(t.needClearance);
          }}
        >
          <div>
            <Label htmlFor="to">{t.recipient}</Label>
            <Input id="to" className="mt-1" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="amt">{t.amount}</Label>
            <Input id="amt" className="mt-1" type="number" min={0.01} step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <div>
            <Label>{t.chainLabel}</Label>
            <select
              className="mt-1 h-11 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]"
              value={chain}
              onChange={(e) => setChain(e.target.value as ChainId)}
            >
              <option value="omni">{t.omni}</option>
              <option value="btc">{t.btc}</option>
              <option value="eth">{t.eth}</option>
              <option value="sol">{t.sol}</option>
              <option value="bsc">{t.bsc}</option>
            </select>
          </div>
          <label className="flex h-11 items-center gap-2 self-end text-sm">
            <input type="checkbox" checked={zk} onChange={(e) => setZk(e.target.checked)} />
            {t.zk} · {t.confidential}
          </label>
          <div className="sm:col-span-2">
            <Button type="submit">{t.confirm}</Button>
          </div>
        </form>
      </Panel>
    </div>
  );
}
