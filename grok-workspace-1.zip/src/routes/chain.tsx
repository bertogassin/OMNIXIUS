import { createFileRoute } from "@tanstack/react-router";
import { ModuleHeader, Panel, Stat } from "@/components/module";
import { Badge } from "@/components/ui/badge";
import { copy } from "@/lib/i18n";
import { ago, oxi } from "@/lib/format";
import { mergeTxs, usePlatform } from "@/lib/store";

export const Route = createFileRoute("/chain")({ component: Chain });

function Chain() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const blocks = usePlatform((s) => s.blocks);
  const extraTxs = usePlatform((s) => s.extraTxs);
  const txs = mergeTxs(extraTxs).slice(0, 12);
  const last = blocks[blocks.length - 1];

  return (
    <div>
      <ModuleHeader kicker={t.capital} title={t.chain} lede={t.chainLede} />
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label={t.height} value={last?.height.toLocaleString() ?? "—"} hint={t.pqc} />
        <Stat label={t.peers} value={t.peersN} />
        <Stat label={t.health} value={t.healthy} />
      </div>
      <div className="mt-5 grid gap-3 lg:grid-cols-2">
        <Panel>
          <p className="type-kicker">{t.lastBlocks}</p>
          <ul className="mt-3 divide-y divide-border">
            {[...blocks].reverse().slice(0, 8).map((b) => (
              <li key={b.hash} className="flex min-h-12 items-center justify-between gap-3 py-2">
                <div>
                  <p className="font-mono text-xs text-primary">{b.hash}</p>
                  <p className="text-xs text-muted">
                    #{b.height} · {b.txCount} · {ago(b.ts, locale)}
                  </p>
                </div>
                {b.pqc ? <Badge tone="success">{t.pqc}</Badge> : null}
              </li>
            ))}
          </ul>
        </Panel>
        <Panel>
          <p className="type-kicker">{t.explorer}</p>
          <ul className="mt-3 divide-y divide-border">
            {txs.map((x) => (
              <li key={x.id} className="py-2">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-mono text-xs text-primary">{x.id}</p>
                  {x.zk ? <Badge>{t.zk}</Badge> : <Badge tone="muted">{x.chain.toUpperCase()}</Badge>}
                </div>
                <p className="mt-1 text-sm">
                  {x.from} → {x.to}
                </p>
                <p className="text-xs text-muted">
                  {oxi(x.amount)} {x.asset} · {t.fee} {oxi(x.fee, 4)}
                </p>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
      <Panel className="mt-3">
        <p className="type-kicker">{t.bridges}</p>
        <ul className="mt-3 grid gap-2 sm:grid-cols-4">
          {[
            ["BTC", "wrapped"],
            ["ETH", "wrapped"],
            ["SOL", "wrapped"],
            ["BSC", "watch"],
          ].map(([name, st]) => (
            <li key={name} className="rounded-lg bg-secondary px-3 py-3">
              <p className="text-sm">{name}</p>
              <p className="text-xs text-muted">{st === "watch" ? t.watch : t.healthy}</p>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
