import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { copy } from "@/lib/i18n";
import { ago } from "@/lib/format";
import { useAsk } from "@/lib/use-ask";
import { usePlatform } from "@/lib/store";

export const Route = createFileRoute("/notepad")({ component: Notepad });

function Notepad() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const notes = usePlatform((s) => s.notes);
  const addNote = usePlatform((s) => s.addNote);
  const setNotePlan = usePlatform((s) => s.setNotePlan);
  const [raw, setRaw] = useState("");
  const { ask, pending } = useAsk();

  return (
    <div>
      <ModuleHeader kicker={t.intel} title={t.notepad} lede={t.noteLede} />
      <Panel>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (!raw.trim()) return;
            const id = addNote(raw.trim());
            const res = await ask("notepad", raw.trim());
            if (res.ok) setNotePlan(id, res.text);
            else toast.error(t.aiDown);
            setRaw("");
          }}
        >
          <Textarea value={raw} onChange={(e) => setRaw(e.target.value)} placeholder={t.notePh} />
          <Button type="submit" className="mt-3" disabled={pending}>
            {pending ? t.thinking : t.plan}
          </Button>
        </form>
      </Panel>
      {notes.length === 0 ? (
        <p className="mt-6 text-sm text-muted">{t.emptyNotes}</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {notes.map((n) => (
            <li key={n.id}>
              <Panel>
                <p className="text-sm">{n.raw}</p>
                <p className="mt-1 text-xs text-muted">{ago(n.ts, locale)}</p>
                {n.plan ? (
                  <pre className="mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-muted">
                    {n.plan}
                  </pre>
                ) : null}
              </Panel>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
