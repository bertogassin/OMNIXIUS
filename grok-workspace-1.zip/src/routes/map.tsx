import { useMemo } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel, VerifBadge } from "@/components/module";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Segmented } from "@/components/ui/tabs";
import { copy } from "@/lib/i18n";
import { oxi } from "@/lib/format";
import { cities, experts } from "@/lib/seed";
import { type Logistics, usePlatform } from "@/lib/store";
import { cityName } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/map")({ component: MapPage });

function fit(userHas: boolean, proHas: boolean, filter: Logistics) {
  if (filter === "need-tools" && !proHas) return "blocked" as const;
  if (filter === "have-tools" && proHas) return "redundant" as const;
  if (!userHas && !proHas) return "blocked" as const;
  if (!userHas && proHas) return "optimal" as const;
  if (userHas && proHas) return "redundant" as const;
  return "ok" as const;
}

function MapPage() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const selected = usePlatform((s) => s.selectedCityId);
  const setSelectedCity = usePlatform((s) => s.setSelectedCity);
  const logistics = usePlatform((s) => s.logistics);
  const setLogistics = usePlatform((s) => s.setLogistics);
  const hasTools = usePlatform((s) => s.passport.hasTools);
  const lockExpert = usePlatform((s) => s.lockExpert);
  const theatre = cities.find((c) => c.id === selected)?.theatre ?? "europe";
  const theatreCities = cities.filter((c) => c.theatre === theatre);

  const shown = useMemo(() => {
    return experts.filter((e) => {
      const city = cities.find((c) => c.id === e.cityId);
      if (!city || city.theatre !== theatre) return false;
      if (selected && e.cityId !== selected) return true;
      return true;
    }).filter((e) => theatreCities.some((c) => c.id === e.cityId));
  }, [theatre, selected, theatreCities]);

  return (
    <div>
      <ModuleHeader kicker={t.field} title={t.map} lede={t.mapLede} />
      <Segmented
        value={theatre}
        onChange={(id) => {
          const first = cities.find((c) => c.theatre === id);
          setSelectedCity(first?.id ?? null);
        }}
        options={[
          { id: "europe", label: t.europe },
          { id: "africa", label: t.africa },
          { id: "asia", label: t.asia },
          { id: "americas", label: t.americas },
        ]}
      />
      <div className="mt-3 flex flex-wrap gap-2">
        {(
          [
            ["any", t.toolsAny],
            ["need-tools", t.youNeed],
            ["have-tools", t.youHave],
          ] as const
        ).map(([id, label]) => (
          <Button
            key={id}
            size="sm"
            variant={logistics === id ? "default" : "outline"}
            onClick={() => setLogistics(id)}
          >
            {label}
          </Button>
        ))}
      </div>
      <Panel className="mt-4 overflow-hidden p-0">
        <Cartograph
          theatre={theatre}
          selected={selected}
          onSelect={setSelectedCity}
        />
      </Panel>
      <ul className="mt-4 grid gap-3 lg:grid-cols-2">
        {shown.map((e) => {
          const f = fit(hasTools, e.hasTools, logistics);
          const blocked = f === "blocked" || e.verification !== "credential";
          return (
            <li key={e.id}>
              <Panel className={cn(selected === e.cityId && "shadow-[var(--shadow-border-hover)]")}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{e.name}</p>
                    <p className="text-sm text-muted">
                      {locale === "ru" ? e.craftRu : e.craft} · {cityName(e.cityId)}
                    </p>
                  </div>
                  <VerifBadge v={e.verification} t={t} />
                </div>
                <p className="mt-2 text-sm text-muted">{locale === "ru" ? e.bioRu : e.bio}</p>
                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted">
                  <Badge tone={e.hasTools ? "success" : "muted"}>{e.hasTools ? t.withTools : t.withoutTools}</Badge>
                  {f === "optimal" ? <Badge tone="success">{t.optimal}</Badge> : null}
                  {f === "redundant" ? <Badge tone="warn">{t.redundant}</Badge> : null}
                  {f === "blocked" ? <Badge tone="danger">{t.blocked}</Badge> : null}
                  <span className="tabular-nums">
                    {oxi(e.rateOxi, 0)} {t.oxi}
                  </span>
                  <span>
                    {e.rating} · {e.reviews}
                  </span>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    disabled={blocked}
                    onClick={() => {
                      if (e.verification !== "credential") {
                        toast.error(t.offerBlocked);
                        return;
                      }
                      const res = lockExpert(e.id, 2);
                      if (res.ok) toast.success(res.free ? t.firstFree : t.lockedOk);
                      else toast.error(t.needClearance);
                    }}
                  >
                    {t.lock}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setSelectedCity(e.cityId)}>
                    {t.dest}
                  </Button>
                </div>
                {e.verification !== "credential" ? (
                  <p className="mt-2 text-xs text-destructive">{t.offerBlocked}</p>
                ) : null}
              </Panel>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Cartograph({
  theatre,
  selected,
  onSelect,
}: {
  theatre: string;
  selected: string | null;
  onSelect: (id: string) => void;
}) {
  const pts = cities.filter((c) => c.theatre === theatre);
  const lats = pts.map((p) => p.lat);
  const lngs = pts.map((p) => p.lng);
  const minLat = Math.min(...lats) - 8;
  const maxLat = Math.max(...lats) + 8;
  const minLng = Math.min(...lngs) - 12;
  const maxLng = Math.max(...lngs) + 12;
  function xy(lat: number, lng: number) {
    const x = ((lng - minLng) / (maxLng - minLng)) * 1000;
    const y = ((maxLat - lat) / (maxLat - minLat)) * 420;
    return { x, y };
  }
  return (
    <svg viewBox="0 0 1000 420" className="h-auto w-full text-primary" role="img">
      <rect width="1000" height="420" fill="var(--color-card)" />
      {Array.from({ length: 8 }, (_, i) => (
        <line
          key={`v${i}`}
          x1={(i + 1) * 110}
          y1="0"
          x2={(i + 1) * 110}
          y2="420"
          stroke="currentColor"
          strokeOpacity="0.06"
        />
      ))}
      {Array.from({ length: 5 }, (_, i) => (
        <line
          key={`h${i}`}
          x1="0"
          y1={(i + 1) * 70}
          x2="1000"
          y2={(i + 1) * 70}
          stroke="currentColor"
          strokeOpacity="0.06"
        />
      ))}
      {pts.map((c) => {
        const { x, y } = xy(c.lat, c.lng);
        const on = c.id === selected;
        return (
          <g key={c.id} transform={`translate(${x},${y})`} className="cursor-pointer" onClick={() => onSelect(c.id)}>
            <circle r={on ? 8 : 5} fill={on ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.4" />
            <text
              y="22"
              textAnchor="middle"
              fill="currentColor"
              style={{ fontSize: 13, fontFamily: "Outfit, sans-serif" }}
            >
              {c.name}
            </text>
          </g>
        );
      })}
    </svg>
  );
}
