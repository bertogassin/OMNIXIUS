import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { PresidentSeal } from "@/components/seal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { copy } from "@/lib/i18n";
import { ago } from "@/lib/format";
import { useAsk } from "@/lib/use-ask";
import { usePlatform } from "@/lib/store";

export const Route = createFileRoute("/president")({ component: President });

function speak(text: string) {
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.95;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  } catch {
    /* no voice */
  }
}

function President() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const clearance = usePlatform((s) => s.passport.clearance);
  const threats = usePlatform((s) => s.threats);
  const patches = usePlatform((s) => s.patches);
  const applyPatch = usePlatform((s) => s.applyPatch);
  const dismissThreat = usePlatform((s) => s.dismissThreat);
  const simulateAttack = usePlatform((s) => s.simulateAttack);
  const setClearance = usePlatform((s) => s.setClearance);
  const { ask, pending } = useAsk();
  const critical = threats.some((x) => x.status === "open" && x.level === "critical");

  if (clearance !== "operator") {
    return (
      <div className="mx-auto max-w-lg py-10 text-center">
        <PresidentSeal className="mx-auto size-16" />
        <h1 className="mt-6 font-display text-3xl">{t.clearanceWall}</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">{t.wallCopy}</p>
        <div className="mt-6 flex justify-center gap-2">
          <Button onClick={() => setClearance("operator")}>{t.switchOp}</Button>
          <Button variant="outline" asChild>
            <Link to="/mvs">{t.mvs}</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <ModuleHeader
        kicker={t.intel}
        title={t.president}
        lede={t.presLede}
        actions={<PresidentSeal className="size-12" live={critical} />}
      />
      <div className="mb-4 flex flex-wrap gap-2">
        <Button
          variant="danger"
          size="sm"
          onClick={() => {
            simulateAttack();
            const line = locale === "ru" ? "Критическая угроза. Президент на связи." : "Critical threat. President engaged.";
            speak(line);
            toast.error(t.critical);
          }}
        >
          {t.simAttack}
        </Button>
        <Button
          variant="outline"
          size="sm"
          disabled={pending}
          onClick={async () => {
            const open = threats.filter((x) => x.status === "open");
            const res = await ask(
              "president",
              open.map((x) => `${x.level}: ${locale === "ru" ? x.titleRu : x.title}`).join("\n") || "Scan layer health.",
            );
            if (res.ok) toast.message(res.text.slice(0, 220));
            else toast.error(t.aiDown);
          }}
        >
          {pending ? t.thinking : t.scan}
        </Button>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        <Panel>
          <p className="type-kicker">{t.openThreats}</p>
          <ul className="mt-3 space-y-3">
            {threats.map((th) => (
              <li key={th.id} className="rounded-lg bg-secondary p-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium">{locale === "ru" ? th.titleRu : th.title}</p>
                  <Badge tone={th.level === "critical" ? "danger" : th.level === "elevated" ? "warn" : "muted"}>
                    {t[th.level]}
                  </Badge>
                </div>
                <p className="mt-1 text-xs text-muted">{locale === "ru" ? th.detailRu : th.detail}</p>
                <p className="mt-1 text-xs text-subtle">
                  {th.status} · {ago(th.ts, locale)}
                </p>
                {th.status === "open" ? (
                  <Button size="sm" variant="ghost" className="mt-2" onClick={() => dismissThreat(th.id)}>
                    {t.dismiss}
                  </Button>
                ) : null}
              </li>
            ))}
          </ul>
        </Panel>
        <Panel>
          <p className="type-kicker">{t.patchLog}</p>
          <ul className="mt-3 space-y-3">
            {patches.map((p) => (
              <li key={p.id} className="rounded-lg bg-secondary p-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-medium">{locale === "ru" ? p.titleRu : p.title}</p>
                  <Badge tone={p.applied ? "success" : "warn"}>{p.applied ? t.applied : t.proposed}</Badge>
                </div>
                <p className="mt-1 text-xs text-muted">{locale === "ru" ? p.detailRu : p.detail}</p>
                {!p.applied ? (
                  <Button
                    size="sm"
                    className="mt-3"
                    onClick={() => {
                      applyPatch(p.id);
                      toast.success(t.patched);
                    }}
                  >
                    {t.applyPatch}
                  </Button>
                ) : null}
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </div>
  );
}
