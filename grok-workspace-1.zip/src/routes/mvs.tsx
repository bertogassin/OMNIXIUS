import { useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { MvsSeal } from "@/components/seal";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { copy } from "@/lib/i18n";
import { uid } from "@/lib/format";
import { useAsk } from "@/lib/use-ask";
import { usePlatform } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/mvs")({ component: Mvs });

function Mvs() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const messages = usePlatform((s) => s.mvs);
  const pushMvs = usePlatform((s) => s.pushMvs);
  const [text, setText] = useState("");
  const { ask, pending } = useAsk();
  const end = useRef<HTMLDivElement>(null);

  return (
    <div>
      <ModuleHeader
        kicker={t.intel}
        title={t.mvs}
        lede={t.mvsLede}
        actions={<MvsSeal className="size-12" live />}
      />
      <Panel className="flex min-h-[28rem] flex-col">
        <div className="flex-1 space-y-3 overflow-y-auto">
          {messages.length === 0 ? (
            <p className="text-sm text-muted">{t.emptyChat}</p>
          ) : (
            messages.map((m) => (
              <div
                key={m.id}
                className={cn(
                  "max-w-[42rem] rounded-lg px-3 py-2 text-sm leading-relaxed",
                  m.role === "user" ? "ml-auto bg-secondary" : "bg-background shadow-[var(--shadow-border)]",
                )}
              >
                {m.text}
              </div>
            ))
          )}
          <div ref={end} />
        </div>
        <form
          className="mt-4"
          onSubmit={async (e) => {
            e.preventDefault();
            const msg = text.trim();
            if (!msg) return;
            setText("");
            pushMvs({ id: uid("m"), role: "user", text: msg, ts: Date.now() });
            const history = [...messages, { role: "user" as const, text: msg }].slice(-10).map((m) => ({
              role: m.role,
              content: m.text,
            }));
            const res = await ask("mvs", msg, history);
            if (res.ok) pushMvs({ id: uid("m"), role: "assistant", text: res.text, ts: Date.now() });
            else toast.error(t.aiDown);
          }}
        >
          <Textarea value={text} onChange={(e) => setText(e.target.value)} placeholder={t.mvsPh} />
          <Button type="submit" className="mt-3" disabled={pending}>
            {pending ? t.thinking : t.send}
          </Button>
        </form>
      </Panel>
    </div>
  );
}
