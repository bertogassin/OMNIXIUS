import { createFileRoute, Link } from "@tanstack/react-router";
import { ModuleHeader, Panel, Stat } from "@/components/module";
import { MvsSeal, PresidentSeal } from "@/components/seal";
import { Badge } from "@/components/ui/badge";
import { copy } from "@/lib/i18n";
import { ago, isValentine, oxi } from "@/lib/format";
import { experts } from "@/lib/seed";
import { mergePosts, mergeTxs, usePlatform } from "@/lib/store";
import { cityName } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Deck });

function Deck() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const passport = usePlatform((s) => s.passport);
  const blocks = usePlatform((s) => s.blocks);
  const contracts = usePlatform((s) => s.contracts);
  const valentineDemo = usePlatform((s) => s.valentineDemo);
  const threats = usePlatform((s) => s.threats);
  const extraPosts = usePlatform((s) => s.extraPosts);
  const extraTxs = usePlatform((s) => s.extraTxs);
  const height = blocks[blocks.length - 1]?.height ?? 0;
  const valentine = isValentine(valentineDemo);
  const nearby = experts.filter((e) => e.available).slice(0, 4);
  const open = threats.filter((x) => x.status === "open");
  const posts = mergePosts(extraPosts).slice(0, 4);
  const txs = mergeTxs(extraTxs).slice(0, 4);
  const spine = [...posts.map((p) => ({ ts: p.ts, kind: "post" as const, p })), ...txs.map((x) => ({ ts: x.ts, kind: "tx" as const, x }))].sort(
    (a, b) => b.ts - a.ts,
  ).slice(0, 6);

  return (
    <div>
      <ModuleHeader kicker={t.kicker} title={t.deck} lede={t.deckLede} />
      {valentine ? (
        <p className="mb-5 rounded-lg bg-secondary px-4 py-3 text-sm text-primary shadow-[var(--shadow-border)]">
          {t.valentine}
        </p>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label={t.height} value={height.toLocaleString()} hint={t.pqc} />
        <Stat label={t.oxi} value={oxi(passport.oxi, 0)} hint={t.peersN} />
        <Stat label={t.trust} value={passport.trust} hint={t.lattice} />
        <Stat
          label={t.threats}
          value={open.length}
          hint={open.some((x) => x.level === "critical") ? t.critical : t.healthy}
        />
      </div>
      <div className="mt-5 grid gap-3 lg:grid-cols-2">
        <Panel>
          <div className="flex items-center gap-3">
            <PresidentSeal className="size-10" live={open.length > 0} />
            <div>
              <p className="type-kicker">{t.president}</p>
              <p className="mt-1 text-sm">{open.length ? t.presidentAlert : t.presidentIdle}</p>
            </div>
            <Link to="/president" className="ml-auto text-sm text-primary">
              {t.continue}
            </Link>
          </div>
        </Panel>
        <Panel>
          <div className="flex items-center gap-3">
            <MvsSeal className="size-10" live />
            <div>
              <p className="type-kicker">{t.mvs}</p>
              <p className="mt-1 text-sm">{t.mvsIdle}</p>
            </div>
            <Link to="/mvs" className="ml-auto text-sm text-primary">
              {t.mvsOpen}
            </Link>
          </div>
        </Panel>
      </div>
      <div className="mt-5 grid gap-3 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <p className="type-kicker">{t.live}</p>
          <ul className="mt-3 divide-y divide-border">
            {spine.map((row) =>
              row.kind === "post" ? (
                <li key={row.p.id} className="flex min-h-14 items-start justify-between gap-3 py-3">
                  <div>
                    <p className="text-sm">{locale === "ru" ? row.p.bodyRu : row.p.body}</p>
                    <p className="mt-1 text-xs text-muted">
                      {row.p.author} · {cityName(row.p.cityId)} · {ago(row.p.ts, locale)}
                    </p>
                  </div>
                </li>
              ) : (
                <li key={row.x.id} className="flex min-h-14 items-start justify-between gap-3 py-3">
                  <div>
                    <p className="font-mono text-xs text-primary">{row.x.id}</p>
                    <p className="mt-1 text-sm">
                      {row.x.from} → {row.x.to} · {oxi(row.x.amount)} {row.x.asset}
                    </p>
                  </div>
                  {row.x.zk ? <Badge>{t.zk}</Badge> : null}
                </li>
              ),
            )}
          </ul>
        </Panel>
        <Panel className="self-start">
          <p className="type-kicker">{t.nearby}</p>
          <ul className="mt-3 space-y-3">
            {nearby.map((e) => (
              <li key={e.id}>
                <Link to="/map" className="block">
                  <p className="text-sm">{e.name}</p>
                  <p className="text-xs text-muted">
                    {locale === "ru" ? e.craftRu : e.craft} · {cityName(e.cityId)}
                  </p>
                </Link>
              </li>
            ))}
          </ul>
          <p className="type-kicker mt-6">{t.contracts}</p>
          {contracts.length === 0 ? (
            <p className="mt-2 text-sm text-muted">{t.emptyContracts}</p>
          ) : (
            <ul className="mt-2 space-y-2">
              {contracts.slice(0, 3).map((c) => (
                <li key={c.id} className="text-sm">
                  {c.title} · {t[c.status]}
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
}
