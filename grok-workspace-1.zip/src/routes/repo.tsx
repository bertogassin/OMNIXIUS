import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { ModuleHeader, Panel } from "@/components/module";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { copy } from "@/lib/i18n";
import { ago } from "@/lib/format";
import { usePlatform } from "@/lib/store";

export const Route = createFileRoute("/repo")({ component: Repo });

function Repo() {
  const locale = usePlatform((s) => s.locale);
  const t = copy(locale);
  const files = usePlatform((s) => s.files);
  const uploadFile = usePlatform((s) => s.uploadFile);
  const [name, setName] = useState("note.pq");

  return (
    <div>
      <ModuleHeader kicker={t.capital} title={t.repo} lede={t.repoLede} />
      <Panel>
        <form
          className="flex flex-col gap-3 sm:flex-row sm:items-end"
          onSubmit={(e) => {
            e.preventDefault();
            uploadFile(name.trim() || "node.pq", 32 + Math.floor(Math.random() * 400));
            toast.success(t.uploaded);
          }}
        >
          <div className="flex-1">
            <Label htmlFor="fn">{t.fileName}</Label>
            <Input id="fn" className="mt-1" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <Button type="submit">{t.upload}</Button>
        </form>
      </Panel>
      <ul className="mt-4 grid gap-3">
        {files.map((f) => (
          <li key={f.id}>
            <Panel>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-medium">{f.name}</p>
                  <p className="text-xs text-muted">
                    {f.sizeKb} KB · {ago(f.ts, locale)}
                  </p>
                </div>
                <div className="flex gap-1">
                  {f.encrypted ? <Badge>{t.encrypted}</Badge> : null}
                  {f.pqc ? <Badge tone="success">{t.pqc}</Badge> : null}
                </div>
              </div>
              <p className="type-kicker mt-4">{t.shards}</p>
              <div className="mt-2 flex h-10 items-end gap-1">
                {Array.from({ length: f.shards }, (_, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-sm bg-primary/70"
                    style={{ height: `${40 + ((i * 17) % 50)}%` }}
                  />
                ))}
              </div>
            </Panel>
          </li>
        ))}
      </ul>
    </div>
  );
}
