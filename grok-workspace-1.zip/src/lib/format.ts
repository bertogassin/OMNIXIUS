import { formatDistanceToNow } from "date-fns";
import { enUS, ru } from "date-fns/locale";
import type { Locale } from "./types";

export function oxi(n: number, digits = 2) {
  return n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function ago(ts: number, locale: Locale) {
  return formatDistanceToNow(ts, {
    addSuffix: true,
    locale: locale === "ru" ? ru : enUS,
  });
}

export function hashOf(input: string, len = 16) {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const a = (h >>> 0).toString(16).padStart(8, "0");
  const b = ((h ^ 0xa5a5a5a5) >>> 0).toString(16).padStart(8, "0");
  return `0x${(a + b).slice(0, len)}`;
}

export function uid(prefix: string) {
  const n = Math.random().toString(36).slice(2, 8);
  const t = Date.now().toString(36).slice(-4);
  return `${prefix}_${t}${n}`;
}

export function isValentine(demo: boolean, now = new Date()) {
  return demo || (now.getMonth() === 1 && now.getDate() === 14);
}

export function project(lat: number, lng: number, w = 1000, h = 520) {
  const x = ((lng + 180) / 360) * w;
  const y = ((90 - lat) / 180) * h;
  return { x, y };
}

export function bearingTo(from: { lat: number; lng: number }, to: { lat: number; lng: number }) {
  const φ1 = (from.lat * Math.PI) / 180;
  const φ2 = (to.lat * Math.PI) / 180;
  const Δλ = ((to.lng - from.lng) * Math.PI) / 180;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  const θ = Math.atan2(y, x);
  return ((θ * 180) / Math.PI + 360) % 360;
}
