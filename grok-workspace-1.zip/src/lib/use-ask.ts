import { useState } from "react";
import { askAgent, type AgentKind } from "@/lib/ai";
import { copy } from "@/lib/i18n";
import { usePlatform } from "@/lib/store";

export function useAsk() {
  const [pending, setPending] = useState(false);
  const locale = usePlatform((s) => s.locale);
  const clearance = usePlatform((s) => s.passport.clearance);
  const t = copy(locale);

  async function ask(
    agent: AgentKind,
    message: string,
    history?: { role: "user" | "assistant"; content: string }[],
  ) {
    setPending(true);
    try {
      const res = await askAgent({
        data: { agent, message, clearance, locale, history },
      });
      if (!res.ok) return { ok: false as const, error: t.aiDown };
      return res;
    } catch {
      return { ok: false as const, error: t.aiDown };
    } finally {
      setPending(false);
    }
  }

  return { ask, pending, t };
}
