import { create } from "zustand";
import type {
  Block,
  ChatMsg,
  City,
  Clearance,
  Contract,
  Listing,
  ListingKind,
  Locale,
  Note,
  Passport,
  Patch,
  PersistSlice,
  SocialPost,
  Threat,
  Tx,
  VaultFile,
  Verification,
} from "./types";
import {
  defaultPassport,
  experts,
  files as seedFiles,
  genesisBlocks,
  GENESIS,
  listings as seedListings,
  posts as seedPosts,
  seedPatches,
  seedThreats,
  seedTxs,
  guards,
  cities,
} from "./seed";
import { hashOf, isValentine, uid } from "./format";

const KEY = "omnixius.v1";
const VER = 1;

function cityById(id: string): City | undefined {
  return cities.find((c) => c.id === id);
}

function persistSlice(s: PlatformState): PersistSlice {
  return {
    v: VER,
    passport: s.passport,
    extraListings: s.extraListings,
    extraPosts: s.extraPosts,
    contracts: s.contracts,
    files: s.files,
    extraTxs: s.extraTxs,
    notes: s.notes,
    mvs: s.mvs,
    threats: s.threats,
    patches: s.patches,
    locale: s.locale,
    bootSeen: s.bootSeen,
    valentineDemo: s.valentineDemo,
    liked: s.liked,
  };
}

function load(): Partial<PersistSlice> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistSlice;
    if (parsed.v !== VER) return null;
    return parsed;
  } catch {
    return null;
  }
}

function save(s: PlatformState) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(KEY, JSON.stringify(persistSlice(s)));
  } catch {
    /* quota */
  }
}

export type Logistics = "any" | "need-tools" | "have-tools";

export type PlatformState = {
  hydrated: boolean;
  locale: Locale;
  bootSeen: boolean;
  valentineDemo: boolean;
  passport: Passport;
  extraListings: Listing[];
  extraPosts: SocialPost[];
  contracts: Contract[];
  files: VaultFile[];
  extraTxs: Tx[];
  notes: Note[];
  mvs: ChatMsg[];
  threats: Threat[];
  patches: Patch[];
  liked: string[];
  blocks: Block[];
  selectedCityId: string | null;
  logistics: Logistics;
  listingKind: ListingKind | "all";
  hydrate: () => void;
  setLocale: (l: Locale) => void;
  setBootSeen: () => void;
  setValentineDemo: (v: boolean) => void;
  setPassport: (p: Partial<Passport>) => void;
  setClearance: (c: Clearance) => void;
  setVerification: (v: Verification) => void;
  setSelectedCity: (id: string | null) => void;
  setLogistics: (l: Logistics) => void;
  setListingKind: (k: ListingKind | "all") => void;
  likePost: (id: string) => void;
  addPost: (body: string) => void;
  addListing: (input: { title: string; kind: ListingKind; priceOxi: number; cityId: string; hiddenRoute: boolean }) => { ok: true } | { ok: false; reason: "offerBlocked" };
  lockExpert: (expertId: string, hours: number) => { ok: true; id: string; free: boolean } | { ok: false; reason: string };
  lockListing: (listingId: string) => { ok: true; id: string; free: boolean } | { ok: false; reason: string };
  dispatchGuard: (guardId: string, sos?: boolean) => { ok: true; id: string; free: boolean } | { ok: false; reason: string };
  setContractStatus: (id: string, status: Contract["status"]) => void;
  uploadFile: (name: string, sizeKb: number) => void;
  sendTx: (input: { to: string; amount: number; asset: string; chain: Tx["chain"]; zk: boolean; memo?: string }) => { ok: true; id: string; free: boolean } | { ok: false; reason: string };
  addNote: (raw: string, plan?: string) => string;
  setNotePlan: (id: string, plan: string) => void;
  pushMvs: (msg: ChatMsg) => void;
  tickChain: () => void;
  applyPatch: (id: string) => void;
  dismissThreat: (id: string) => void;
  simulateAttack: () => void;
  resetDemo: () => void;
};

const initial: Omit<
  PlatformState,
  | "hydrate"
  | "setLocale"
  | "setBootSeen"
  | "setValentineDemo"
  | "setPassport"
  | "setClearance"
  | "setVerification"
  | "setSelectedCity"
  | "setLogistics"
  | "setListingKind"
  | "likePost"
  | "addPost"
  | "addListing"
  | "lockExpert"
  | "lockListing"
  | "dispatchGuard"
  | "setContractStatus"
  | "uploadFile"
  | "sendTx"
  | "addNote"
  | "setNotePlan"
  | "pushMvs"
  | "tickChain"
  | "applyPatch"
  | "dismissThreat"
  | "simulateAttack"
  | "resetDemo"
> = {
  hydrated: false,
  locale: "ru",
  bootSeen: false,
  valentineDemo: false,
  passport: { ...defaultPassport },
  extraListings: [],
  extraPosts: [],
  contracts: [],
  files: [...seedFiles],
  extraTxs: [],
  notes: [],
  mvs: [],
  threats: [...seedThreats],
  patches: [...seedPatches],
  liked: [],
  blocks: [...genesisBlocks],
  selectedCityId: "zurich",
  logistics: "any",
  listingKind: "all",
};

function feeFor(amount: number, valentine: boolean, used: boolean) {
  if (valentine && !used) return 0;
  return Math.max(0.05, amount * 0.002);
}

export const usePlatform = create<PlatformState>((set, get) => ({
  ...initial,
  hydrate: () => {
    const loaded = load();
    if (!loaded) {
      set({ hydrated: true });
      return;
    }
    set({
      hydrated: true,
      locale: loaded.locale ?? "ru",
      bootSeen: loaded.bootSeen ?? false,
      valentineDemo: loaded.valentineDemo ?? false,
      passport: { ...defaultPassport, ...loaded.passport },
      extraListings: loaded.extraListings ?? [],
      extraPosts: loaded.extraPosts ?? [],
      contracts: loaded.contracts ?? [],
      files: loaded.files && loaded.files.length ? loaded.files : [...seedFiles],
      extraTxs: loaded.extraTxs ?? [],
      notes: loaded.notes ?? [],
      mvs: loaded.mvs ?? [],
      threats: loaded.threats && loaded.threats.length ? loaded.threats : [...seedThreats],
      patches: loaded.patches && loaded.patches.length ? loaded.patches : [...seedPatches],
      liked: loaded.liked ?? [],
    });
  },
  setLocale: (l) => {
    set({ locale: l });
    save(get());
  },
  setBootSeen: () => {
    set({ bootSeen: true });
    save(get());
  },
  setValentineDemo: (v) => {
    set({ valentineDemo: v });
    save(get());
  },
  setPassport: (p) => {
    set({ passport: { ...get().passport, ...p } });
    save(get());
  },
  setClearance: (c) => {
    set({ passport: { ...get().passport, clearance: c } });
    save(get());
  },
  setVerification: (v) => {
    set({ passport: { ...get().passport, verification: v } });
    save(get());
  },
  setSelectedCity: (id) => set({ selectedCityId: id }),
  setLogistics: (l) => set({ logistics: l }),
  setListingKind: (k) => set({ listingKind: k }),
  likePost: (id) => {
    const liked = get().liked.includes(id)
      ? get().liked.filter((x) => x !== id)
      : [...get().liked, id];
    set({ liked });
    save(get());
  },
  addPost: (body) => {
    const p = get().passport;
    const post: SocialPost = {
      id: uid("p"),
      author: p.name,
      cityId: "zurich",
      body,
      bodyRu: body,
      ts: Date.now(),
      likes: 0,
    };
    set({ extraPosts: [post, ...get().extraPosts] });
    save(get());
  },
  addListing: (input) => {
    const v = get().passport.verification;
    if (input.kind === "service" && v !== "credential") {
      return { ok: false as const, reason: "offerBlocked" };
    }
    const listing: Listing = {
      id: uid("l"),
      title: input.title,
      titleRu: input.title,
      kind: input.kind,
      cityId: input.cityId,
      priceOxi: input.priceOxi,
      seller: get().passport.name,
      hiddenRoute: input.hiddenRoute,
      blurb: input.title,
      blurbRu: input.title,
    };
    set({ extraListings: [listing, ...get().extraListings] });
    save(get());
    return { ok: true as const };
  },
  lockExpert: (expertId, hours) => {
    const ex = experts.find((e) => e.id === expertId);
    if (!ex) return { ok: false as const, reason: "missing" };
    if (ex.verification !== "credential") {
      return { ok: false as const, reason: "offerBlocked" };
    }
    const amount = ex.rateOxi * hours;
    const valentine = isValentine(get().valentineDemo);
    const free = valentine && !get().passport.valentineUsed;
    const fee = feeFor(amount, valentine, get().passport.valentineUsed);
    if (get().passport.oxi < amount + fee) return { ok: false as const, reason: "funds" };
    const id = uid("c");
    const c: Contract = {
      id,
      kind: "service",
      title: ex.craft,
      counterparty: ex.name,
      cityId: ex.cityId,
      amount,
      status: "locked",
      ts: Date.now(),
      hiddenRoute: false,
    };
    set({
      contracts: [c, ...get().contracts],
      passport: {
        ...get().passport,
        oxi: get().passport.oxi - amount - fee,
        valentineUsed: get().passport.valentineUsed || free,
        trust: Math.min(99, get().passport.trust + 1),
      },
      extraTxs: [
        {
          id: hashOf(id),
          from: `@${get().passport.handle}`,
          to: ex.name,
          amount,
          asset: "OXI",
          chain: "omni",
          zk: false,
          ts: Date.now(),
          fee,
          memo: free ? "valentine" : "service",
        },
        ...get().extraTxs,
      ],
      selectedCityId: ex.cityId,
    });
    save(get());
    return { ok: true as const, id, free };
  },
  lockListing: (listingId) => {
    const all = [...get().extraListings, ...seedListings];
    const lot = all.find((l) => l.id === listingId);
    if (!lot) return { ok: false as const, reason: "missing" };
    const amount = lot.priceOxi;
    const valentine = isValentine(get().valentineDemo);
    const free = valentine && !get().passport.valentineUsed;
    const fee = feeFor(amount, valentine, get().passport.valentineUsed);
    if (get().passport.oxi < amount + fee) return { ok: false as const, reason: "funds" };
    const id = uid("c");
    const kind = lot.kind === "land" ? "lease" : lot.kind === "service" ? "service" : "trade";
    const c: Contract = {
      id,
      kind,
      title: lot.title,
      counterparty: lot.seller,
      cityId: lot.cityId,
      amount,
      status: "locked",
      ts: Date.now(),
      hiddenRoute: lot.hiddenRoute,
    };
    set({
      contracts: [c, ...get().contracts],
      passport: {
        ...get().passport,
        oxi: get().passport.oxi - amount - fee,
        valentineUsed: get().passport.valentineUsed || free,
        trust: Math.min(99, get().passport.trust + 1),
      },
      extraTxs: [
        {
          id: hashOf(id),
          from: `@${get().passport.handle}`,
          to: lot.seller,
          amount,
          asset: "OXI",
          chain: "omni",
          zk: lot.hiddenRoute,
          ts: Date.now(),
          fee,
          memo: free ? "valentine" : lot.kind,
        },
        ...get().extraTxs,
      ],
      selectedCityId: lot.cityId,
    });
    save(get());
    return { ok: true as const, id, free };
  },
  dispatchGuard: (guardId, sos) => {
    const g = guards.find((x) => x.id === guardId);
    if (!g) return { ok: false as const, reason: "missing" };
    const amount = g.rateOxi;
    const valentine = isValentine(get().valentineDemo);
    const free = valentine && !get().passport.valentineUsed;
    const fee = feeFor(amount, valentine, get().passport.valentineUsed);
    if (get().passport.oxi < amount + fee) return { ok: false as const, reason: "funds" };
    const id = uid("c");
    const c: Contract = {
      id,
      kind: "guard",
      title: sos ? `SOS · ${g.firm}` : g.firm,
      counterparty: g.firm,
      cityId: g.cityId,
      amount,
      status: "in_field",
      ts: Date.now(),
      hiddenRoute: true,
      notes: sos ? "sos" : undefined,
    };
    set({
      contracts: [c, ...get().contracts],
      passport: {
        ...get().passport,
        oxi: get().passport.oxi - amount - fee,
        valentineUsed: get().passport.valentineUsed || free,
        trust: Math.min(99, get().passport.trust + 1),
      },
      extraTxs: [
        {
          id: hashOf(id),
          from: `@${get().passport.handle}`,
          to: g.firm,
          amount,
          asset: "OXI",
          chain: "omni",
          zk: true,
          ts: Date.now(),
          fee,
          memo: sos ? "sos" : "guard",
        },
        ...get().extraTxs,
      ],
      selectedCityId: g.cityId,
    });
    save(get());
    return { ok: true as const, id, free };
  },
  setContractStatus: (id, status) => {
    set({
      contracts: get().contracts.map((c) => (c.id === id ? { ...c, status } : c)),
    });
    save(get());
  },
  uploadFile: (name, sizeKb) => {
    const f: VaultFile = {
      id: uid("f"),
      name,
      sizeKb,
      shards: 4,
      encrypted: true,
      pqc: true,
      ts: Date.now(),
    };
    set({ files: [f, ...get().files] });
    save(get());
  },
  sendTx: (input) => {
    const amount = input.amount;
    const valentine = isValentine(get().valentineDemo);
    const free = valentine && !get().passport.valentineUsed;
    const fee = input.asset === "OXI" ? feeFor(amount, valentine, get().passport.valentineUsed) : amount * 0.001;
    const p = get().passport;
    if (input.asset === "OXI" && p.oxi < amount + fee) return { ok: false as const, reason: "funds" };
    const id = hashOf(uid("tx"));
    const tx: Tx = {
      id,
      from: `@${p.handle}`,
      to: input.to,
      amount,
      asset: input.asset,
      chain: input.chain,
      zk: input.zk,
      ts: Date.now(),
      fee,
      memo: input.memo ?? (free ? "valentine" : undefined),
    };
    const next = { ...p, valentineUsed: p.valentineUsed || (free && input.asset === "OXI") };
    if (input.asset === "OXI") next.oxi = p.oxi - amount - fee;
    if (input.asset === "WBTC") next.wbtc = p.wbtc - amount;
    if (input.asset === "WETH") next.weth = p.weth - amount;
    if (input.asset === "SOL") next.sol = p.sol - amount;
    if (input.asset === "BNB") next.bnb = p.bnb - amount;
    set({ extraTxs: [tx, ...get().extraTxs], passport: next });
    save(get());
    return { ok: true as const, id, free };
  },
  addNote: (raw, plan) => {
    const id = uid("n");
    const n: Note = { id, raw, plan, ts: Date.now() };
    set({ notes: [n, ...get().notes] });
    save(get());
    return id;
  },
  setNotePlan: (id, plan) => {
    set({ notes: get().notes.map((n) => (n.id === id ? { ...n, plan } : n)) });
    save(get());
  },
  pushMvs: (msg) => {
    set({ mvs: [...get().mvs, msg] });
    save(get());
  },
  tickChain: () => {
    const blocks = get().blocks;
    const last = blocks[blocks.length - 1];
    if (!last) return;
    const height = last.height + 1;
    const b: Block = {
      height,
      hash: hashOf(`block-${height}-${Date.now()}`),
      txCount: 1 + (height % 5),
      ts: Date.now(),
      pqc: true,
    };
    const next = [...blocks, b];
    set({ blocks: next.slice(-24) });
  },
  applyPatch: (id) => {
    set({
      patches: get().patches.map((p) => (p.id === id ? { ...p, applied: true } : p)),
      threats: get().threats.map((t) =>
        t.status === "open" && t.level !== "critical" ? { ...t, status: "patched" } : t,
      ),
    });
    save(get());
  },
  dismissThreat: (id) => {
    set({
      threats: get().threats.map((t) => (t.id === id ? { ...t, status: "dismissed" } : t)),
    });
    save(get());
  },
  simulateAttack: () => {
    const id = uid("th");
    const threat: Threat = {
      id,
      level: "critical",
      title: "Unsigned state transition on shard 2",
      titleRu: "Неподписанный переход состояния, шард 2",
      detail: "President halted the transition. A policy patch is queued. No binary rewrite.",
      detailRu: "Президент остановил переход. Политический патч в очереди. Без переписи бинаря.",
      ts: Date.now(),
      status: "open",
    };
    const patch: Patch = {
      id: uid("pa"),
      title: "Require dual signature on shard 2 commits",
      titleRu: "Двойная подпись на коммитах шарда 2",
      detail: "Policy only. Operator must accept. Core will not self-rewrite.",
      detailRu: "Только политика. Нужно слово оператора. Ядро само себя не переписывает.",
      ts: Date.now(),
      applied: false,
    };
    set({ threats: [threat, ...get().threats], patches: [patch, ...get().patches] });
    save(get());
  },
  resetDemo: () => {
    if (typeof window !== "undefined") localStorage.removeItem(KEY);
    set({
      ...initial,
      hydrated: true,
      blocks: [...genesisBlocks],
    });
  },
}));

export function allListings(s: PlatformState) {
  return [...s.extraListings, ...seedListings];
}

export function allPosts(s: PlatformState) {
  return [...s.extraPosts, ...seedPosts].sort((a, b) => b.ts - a.ts);
}

export function allTxs(s: PlatformState) {
  return [...s.extraTxs, ...seedTxs].sort((a, b) => b.ts - a.ts);
}

export function mergeListings(extra: Listing[]) {
  return [...extra, ...seedListings];
}

export function mergePosts(extra: SocialPost[]) {
  return [...extra, ...seedPosts].sort((a, b) => b.ts - a.ts);
}

export function mergeTxs(extra: Tx[]) {
  return [...extra, ...seedTxs].sort((a, b) => b.ts - a.ts);
}

export function openThreats(s: PlatformState) {
  return s.threats.filter((t) => t.status === "open");
}

export function cityName(id: string) {
  return cityById(id)?.name ?? id;
}

export { cityById, GENESIS };
