export type Locale = "ru" | "en";
export type Clearance = "citizen" | "pro" | "operator";
export type Verification = "none" | "identity" | "credential";
export type ListingKind = "goods" | "land" | "auto" | "service";
export type ContractKind = "service" | "guard" | "trade" | "lease";
export type ContractStatus =
  | "locked"
  | "in_field"
  | "disputed"
  | "resolved"
  | "cancelled";
export type ChainId = "omni" | "btc" | "eth" | "sol" | "bsc";
export type ThreatLevel = "watch" | "elevated" | "critical";

export type City = {
  id: string;
  name: string;
  country: string;
  countryRu: string;
  lat: number;
  lng: number;
  theatre: "europe" | "africa" | "asia" | "americas";
};

export type Expert = {
  id: string;
  name: string;
  craft: string;
  craftRu: string;
  cityId: string;
  verification: Verification;
  hasTools: boolean;
  rateOxi: number;
  rating: number;
  reviews: number;
  languages: string[];
  bio: string;
  bioRu: string;
  available: boolean;
};

export type Guard = {
  id: string;
  firm: string;
  cityId: string;
  responseMin: number;
  armed: boolean;
  available: boolean;
  rateOxi: number;
  units: number;
};

export type Listing = {
  id: string;
  title: string;
  titleRu: string;
  kind: ListingKind;
  cityId: string;
  priceOxi: number;
  seller: string;
  hiddenRoute: boolean;
  blurb: string;
  blurbRu: string;
};

export type SocialPost = {
  id: string;
  author: string;
  cityId: string;
  body: string;
  bodyRu: string;
  ts: number;
  likes: number;
  liked?: boolean;
};

export type VaultFile = {
  id: string;
  name: string;
  sizeKb: number;
  shards: number;
  encrypted: boolean;
  pqc: boolean;
  ts: number;
};

export type Tx = {
  id: string;
  from: string;
  to: string;
  amount: number;
  asset: string;
  chain: ChainId;
  zk: boolean;
  ts: number;
  memo?: string;
  fee: number;
};

export type Block = {
  height: number;
  hash: string;
  txCount: number;
  ts: number;
  pqc: boolean;
};

export type Contract = {
  id: string;
  kind: ContractKind;
  title: string;
  counterparty: string;
  cityId: string;
  amount: number;
  status: ContractStatus;
  ts: number;
  hiddenRoute: boolean;
  notes?: string;
};

export type Threat = {
  id: string;
  level: ThreatLevel;
  title: string;
  titleRu: string;
  detail: string;
  detailRu: string;
  ts: number;
  status: "open" | "patched" | "dismissed";
};

export type Patch = {
  id: string;
  title: string;
  titleRu: string;
  detail: string;
  detailRu: string;
  ts: number;
  applied: boolean;
};

export type Note = {
  id: string;
  raw: string;
  plan?: string;
  ts: number;
};

export type ChatMsg = {
  id: string;
  role: "user" | "assistant";
  text: string;
  ts: number;
};

export type Passport = {
  name: string;
  handle: string;
  clearance: Clearance;
  verification: Verification;
  trust: number;
  languages: string[];
  tools: string[];
  hasTools: boolean;
  oxi: number;
  wbtc: number;
  weth: number;
  sol: number;
  bnb: number;
  valentineUsed: boolean;
};

export type PersistSlice = {
  v: number;
  passport: Passport;
  extraListings: Listing[];
  extraPosts: SocialPost[];
  contracts: Contract[];
  files: VaultFile[];
  extraTxs: Tx[];
  notes: Note[];
  mvs: ChatMsg[];
  threats: Threat[];
  patches: Patch[];
  locale: Locale;
  bootSeen: boolean;
  valentineDemo: boolean;
  liked: string[];
};
