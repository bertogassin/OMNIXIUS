import { createServerFn } from "@tanstack/react-start";

export type AgentKind = "mvs" | "president" | "notepad";

const SYSTEMS: Record<AgentKind, string> = {
  mvs: `You are MVS, Minister of Foreign Affairs of the OMNIXIUS omni-platform.
You onboard people, translate, and give cautious market and logistics advice.
Never promise returns. Never invent prices or legal facts.
Citizen clearance: stay high-level. Operator clearance: you may discuss protocol, treasury risk, and threat context.
Reply in the user's language. No emoji. Short paragraphs. If giving advice, include one risk line.`,
  president: `You are President, the local guardian core of OMNIXIUS.
You watch state transitions, contracts, and threats.
You MUST NOT claim you can recompile or patch live binaries. You only propose policy/UI patches the operator must accept.
Structure: OBSERVED / RISK / ACTION. Reply in the user's language. No emoji. No theatrics.`,
  notepad: `You turn a raw note into a concrete plan for the OMNIXIUS operator.
Output: Goal, Steps (numbered), Blockers, Next 24h. Reply in the user's language. No emoji.`,
};

export const askAgent = createServerFn({ method: "POST" })
  .validator((input: {
    agent: AgentKind;
    message: string;
    clearance: string;
    locale: string;
    history?: { role: "user" | "assistant"; content: string }[];
  }) => {
    const message = (input.message ?? "").trim().slice(0, 3000);
    if (!message) throw new Error("empty");
    const agent: AgentKind =
      input.agent === "president" || input.agent === "notepad" ? input.agent : "mvs";
    return {
      agent,
      message,
      clearance: input.clearance.slice(0, 24),
      locale: input.locale === "en" ? "en" : "ru",
      history: (input.history ?? []).slice(-10).map((m) => ({
        role: m.role === "assistant" ? "assistant" as const : "user" as const,
        content: m.content.slice(0, 2000),
      })),
    };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "unavailable" };

    const messages = [
      {
        role: "system" as const,
        content: `${SYSTEMS[data.agent]}\nClearance: ${data.clearance}. Locale: ${data.locale}.`,
      },
      ...data.history,
      { role: "user" as const, content: data.message },
    ];

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        messages,
        max_tokens: 700,
        temperature: 0.4,
      }),
    });
    if (!res.ok) return { ok: false as const, error: `xAI ${res.status}` };
    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "empty" };
    return { ok: true as const, text };
  });
