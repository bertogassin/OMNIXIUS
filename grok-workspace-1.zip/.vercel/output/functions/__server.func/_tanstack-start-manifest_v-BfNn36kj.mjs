//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BfNn36kj.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/agora",
			"/chain",
			"/guardio",
			"/map",
			"/mvs",
			"/nexus",
			"/notepad",
			"/passport",
			"/president",
			"/repo",
			"/vault"
		],
		preloads: ["/assets/index-D5eWJaBZ.js", "/assets/store-S1Mj6Rnp.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D5eWJaBZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-z_fNyr9d.js", "/assets/module-XiyBpSD_.js"]
	},
	"/agora": {
		filePath: "/workspace/src/routes/agora.tsx",
		children: void 0,
		preloads: [
			"/assets/agora-C_m6c0y_.js",
			"/assets/module-XiyBpSD_.js",
			"/assets/tabs-C177JaT-.js"
		]
	},
	"/chain": {
		filePath: "/workspace/src/routes/chain.tsx",
		children: void 0,
		preloads: ["/assets/chain-DfJp6wmc.js", "/assets/module-XiyBpSD_.js"]
	},
	"/guardio": {
		filePath: "/workspace/src/routes/guardio.tsx",
		children: void 0,
		preloads: ["/assets/guardio-BuvakHej.js", "/assets/module-XiyBpSD_.js"]
	},
	"/map": {
		filePath: "/workspace/src/routes/map.tsx",
		children: void 0,
		preloads: [
			"/assets/map-BZC0VEFl.js",
			"/assets/module-XiyBpSD_.js",
			"/assets/tabs-C177JaT-.js"
		]
	},
	"/mvs": {
		filePath: "/workspace/src/routes/mvs.tsx",
		children: void 0,
		preloads: [
			"/assets/mvs-ft63brDh.js",
			"/assets/use-ask-CP9K2nTx.js",
			"/assets/module-XiyBpSD_.js"
		]
	},
	"/nexus": {
		filePath: "/workspace/src/routes/nexus.tsx",
		children: void 0,
		preloads: ["/assets/nexus-UscjNhjj.js", "/assets/module-XiyBpSD_.js"]
	},
	"/notepad": {
		filePath: "/workspace/src/routes/notepad.tsx",
		children: void 0,
		preloads: [
			"/assets/notepad-DXhUNyPZ.js",
			"/assets/use-ask-CP9K2nTx.js",
			"/assets/module-XiyBpSD_.js"
		]
	},
	"/passport": {
		filePath: "/workspace/src/routes/passport.tsx",
		children: void 0,
		preloads: [
			"/assets/passport-ClOYCJoR.js",
			"/assets/module-XiyBpSD_.js",
			"/assets/tabs-C177JaT-.js"
		]
	},
	"/president": {
		filePath: "/workspace/src/routes/president.tsx",
		children: void 0,
		preloads: [
			"/assets/president-6aIxoPGq.js",
			"/assets/use-ask-CP9K2nTx.js",
			"/assets/module-XiyBpSD_.js"
		]
	},
	"/repo": {
		filePath: "/workspace/src/routes/repo.tsx",
		children: void 0,
		preloads: ["/assets/repo-D5Pl3rEw.js", "/assets/module-XiyBpSD_.js"]
	},
	"/vault": {
		filePath: "/workspace/src/routes/vault.tsx",
		children: void 0,
		preloads: ["/assets/vault-B-gRMFdY.js", "/assets/module-XiyBpSD_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
