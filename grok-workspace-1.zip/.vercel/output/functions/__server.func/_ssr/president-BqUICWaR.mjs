import { n as ago, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { l as PresidentSeal, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
import { t as useAsk } from "./use-ask-BdvHF2yr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/president-BqUICWaR.js
var import_jsx_runtime = require_jsx_runtime();
function speak(text) {
	try {
		const u = new SpeechSynthesisUtterance(text);
		u.rate = .95;
		window.speechSynthesis.cancel();
		window.speechSynthesis.speak(u);
	} catch {}
}
function President() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const clearance = usePlatform((s) => s.passport.clearance);
	const threats = usePlatform((s) => s.threats);
	const patches = usePlatform((s) => s.patches);
	const applyPatch = usePlatform((s) => s.applyPatch);
	const dismissThreat = usePlatform((s) => s.dismissThreat);
	const simulateAttack = usePlatform((s) => s.simulateAttack);
	const setClearance = usePlatform((s) => s.setClearance);
	const { ask, pending } = useAsk();
	const critical = threats.some((x) => x.status === "open" && x.level === "critical");
	if (clearance !== "operator") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresidentSeal, { className: "mx-auto size-16" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 font-display text-3xl",
				children: t.clearanceWall
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: t.wallCopy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex justify-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => setClearance("operator"),
					children: t.switchOp
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/mvs",
						children: t.mvs
					})
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.intel,
			title: t.president,
			lede: t.presLede,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresidentSeal, {
				className: "size-12",
				live: critical
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				size: "sm",
				onClick: () => {
					simulateAttack();
					speak(locale === "ru" ? "Критическая угроза. Президент на связи." : "Critical threat. President engaged.");
					toast.error(t.critical);
				},
				children: t.simAttack
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				size: "sm",
				disabled: pending,
				onClick: async () => {
					const open = threats.filter((x) => x.status === "open");
					const res = await ask("president", open.map((x) => `${x.level}: ${locale === "ru" ? x.titleRu : x.title}`).join("\n") || "Scan layer health.");
					if (res.ok) toast.message(res.text.slice(0, 220));
					else toast.error(t.aiDown);
				},
				children: pending ? t.thinking : t.scan
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.openThreats
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-3",
				children: threats.map((th) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-secondary p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: locale === "ru" ? th.titleRu : th.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: th.level === "critical" ? "danger" : th.level === "elevated" ? "warn" : "muted",
								children: t[th.level]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: locale === "ru" ? th.detailRu : th.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-subtle",
							children: [
								th.status,
								" · ",
								ago(th.ts, locale)
							]
						}),
						th.status === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							className: "mt-2",
							onClick: () => dismissThreat(th.id),
							children: t.dismiss
						}) : null
					]
				}, th.id))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.patchLog
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-3",
				children: patches.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-secondary p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: locale === "ru" ? p.titleRu : p.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: p.applied ? "success" : "warn",
								children: p.applied ? t.applied : t.proposed
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: locale === "ru" ? p.detailRu : p.detail
						}),
						!p.applied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "mt-3",
							onClick: () => {
								applyPatch(p.id);
								toast.success(t.patched);
							},
							children: t.applyPatch
						}) : null
					]
				}, p.id))
			})] })]
		})
	] });
}
//#endregion
export { President as component };
