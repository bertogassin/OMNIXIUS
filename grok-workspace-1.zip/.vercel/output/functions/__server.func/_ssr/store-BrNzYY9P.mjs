import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as formatDistanceToNow, r as enUS, t as ru } from "../_libs/date-fns.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-BrNzYY9P.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var dict = {
	ru: {
		app: "OMNIXIUS",
		kicker: "Суверенный слой",
		deck: "Мостик",
		map: "BOLH",
		agora: "Агора",
		guardio: "Guardio",
		vault: "Vault",
		nexus: "Nexus",
		repo: "Repositorium",
		chain: "Omni-L1",
		notepad: "Блокнот",
		mvs: "MVS",
		president: "Президент",
		passport: "Паспорт",
		search: "Поиск по слою",
		sos: "SOS",
		lang: "EN",
		operator: "Оператор",
		citizen: "Гражданин",
		pro: "Pro",
		verified: "Диплом",
		identity: "Личность",
		unverified: "Без допуска",
		trust: "Доверие",
		height: "Высота",
		peers: "Узлы",
		pqc: "PQC",
		oxi: "OXI",
		nearby: "В поле",
		contracts: "Контракты",
		threats: "Угрозы",
		live: "Живая лента",
		valentine: "Протокол 14 февраля — первая операция года без комиссии",
		valentineOn: "Демо 14 февраля",
		bootA: "Поднимаем суверенный слой",
		bootB: "Криптография · согласование · допуск",
		enter: "Войти",
		compass: "Компас",
		dest: "Курс",
		noDest: "Нет цели",
		agents: "Агенты",
		presidentIdle: "Сторож спокоен",
		presidentAlert: "Сторож на связи",
		mvsIdle: "MVS готов",
		mvsOpen: "Открыть канал",
		field: "Поле",
		capital: "Капитал",
		people: "Люди",
		intel: "Разведка",
		more: "Ещё",
		toolsHave: "Свои инструменты",
		toolsNeed: "Нужны инструменты",
		toolsAny: "Любая логистика",
		match: "Совпадение",
		mismatch: "Разъезд",
		lock: "Закрыть контракт",
		dispatch: "Вызвать",
		offerBlocked: "Без диплома нельзя предлагать сертифицированную услугу",
		hidden: "Маршрут скрыт",
		approx: "Квадрат",
		available: "На связи",
		busy: "Занят",
		armed: "Вооружён",
		unarmed: "Без оружия",
		response: "Выезд",
		min: "мин",
		rate: "Ставка",
		buy: "Купить",
		lease: "Аренда",
		post: "Опубликовать",
		like: "Отметить",
		upload: "Загрузить узел",
		shards: "Осколки",
		encrypted: "Шифр",
		send: "Отправить",
		zk: "ZK",
		bridge: "Мост",
		firstFree: "Комиссия 0 — Valentine",
		plan: "Собрать план",
		notePh: "Мысль, поручение, риск…",
		mvsPh: "Спросить MVS — рынок, допуск, перевод",
		scan: "Сканировать слой",
		apply: "Принять патч",
		dismiss: "Снять",
		dispute: "Чёрный ящик",
		resolveA: "В пользу заказчика",
		resolveB: "В пользу исполнителя",
		clearanceWall: "Только операторский допуск",
		wallCopy: "Президент — локальный сторож ядра. Гражданам доступен MVS. Переключите допуск в паспорте, чтобы войти.",
		switchOp: "Стать оператором",
		save: "Сохранить",
		name: "Имя",
		handle: "Маркер",
		languages: "Языки",
		myTools: "Инструменты",
		requestId: "Запросить личность",
		requestCred: "Подать диплом",
		balance: "Балансы",
		spark: "OXI / 30 суток",
		genesis: "Генезис",
		mempool: "Мемпул",
		from: "От",
		to: "Кому",
		amount: "Сумма",
		memo: "Мемо",
		chainLabel: "Цепь",
		fee: "Комиссия",
		confirm: "Подтвердить",
		empty: "Пусто",
		emptyNotes: "Запишите мысль — MVS разложит её в план.",
		emptyChat: "MVS молчит, пока вы не заговорите.",
		emptyContracts: "Нет живых контрактов.",
		risk: "Риск-совет",
		onSite: "На месте",
		stream: "Канал агента",
		close: "Закрыть",
		cancel: "Отмена",
		city: "Город",
		theatre: "Театр",
		europe: "Европа и Кавказ",
		africa: "Залив и Африка",
		asia: "Азия-Тихий",
		americas: "Америки",
		goods: "Товар",
		land: "Земля",
		auto: "Авто",
		service: "Услуга",
		all: "Все",
		experts: "Мастера",
		guards: "Караулы",
		listings: "Лоты",
		files: "Узлы",
		aiDown: "ИИ сейчас недоступен. Повторите запрос.",
		thinking: "Думает…",
		speak: "Голос",
		patched: "Патч принят",
		dismissed: "Снято",
		lockedOk: "Контракт закрыт",
		dispatched: "Караул выехал",
		sosSent: "SOS принят — ближайший караул закрыт",
		posted: "Опубликовано",
		uploaded: "Узел записан",
		sent: "Транзакция в блоке",
		needClearance: "Недостаточно допуска",
		hours: "часов",
		kind: "Тип",
		status: "Статус",
		locked: "Закрыт",
		in_field: "В поле",
		disputed: "Спор",
		resolved: "Решён",
		cancelled: "Отменён",
		watch: "Наблюдение",
		elevated: "Повышен",
		critical: "Критично",
		peersN: "4 шарда · 18 узлов",
		deckLede: "Состояние слоя, агенты и ближайшие обязательства — в одной плоскости.",
		mapLede: "Люди, земля, авто и караулы. Фильтр инструментов снижает лишние выезды.",
		agoraLede: "Единый рынок: лоты, аренда, авто и полевые услуги.",
		guardLede: "Параметры караула фиксируются в контракте за один такт.",
		vaultLede: "Казна, мосты и конфиденциальные переводы.",
		nexusLede: "Лента слоя — короткие донесения, не витрина.",
		repoLede: "Шардированное хранение с постквантовым конвертом.",
		chainLede: "Omni-L1: PQC-блоки, ZK-мемо, обёртки BTC / ETH / SOL / BSC.",
		noteLede: "Мысль сразу становится планом с шагами и блокерами.",
		mvsLede: "Министр внешних связей: допуск, перевод, осторожный совет.",
		presLede: "Невидимый сторож ядра. Патчи только после вашего слова.",
		passLede: "Единый паспорт на все модули. Допуск и диплом — не одно и то же.",
		self: "Вы",
		none: "Нет",
		identityLong: "Личность",
		credentialLong: "Диплом / Pro",
		citizenLong: "Гражданин",
		proLong: "Pro",
		operatorLong: "Оператор",
		lattice: "Решётка доверия",
		latticeCopy: "Паспорт связывает поле, казну и караул. Один счёт доверия.",
		newListing: "Новый лот",
		title: "Название",
		price: "Цена",
		publishLot: "Выставить",
		recipient: "Адрес / маркер",
		omni: "OMNI",
		btc: "BTC",
		eth: "ETH",
		sol: "SOL",
		bsc: "BSC",
		confidential: "Скрыть маршрут",
		applyPatch: "Применить",
		proposed: "Предложен",
		applied: "В ядре",
		openThreats: "Открытые",
		lastBlocks: "Последние блоки",
		bridges: "Мосты",
		noMatch: "Нет мастеров под фильтр",
		withTools: "С инструментом",
		withoutTools: "Без инструмента",
		youHave: "У вас есть",
		youNeed: "Вам привезти",
		logistics: "Логистика",
		optimal: "Оптимально",
		redundant: "Дубль",
		blocked: "Нельзя выехать",
		commandHint: "⌘K / Ctrl+K",
		modules: "Модули",
		noResults: "Ничего",
		simAttack: "Симулировать атаку",
		voiceAlert: "Голосовой сигнал",
		patchLog: "Журнал патчей",
		health: "Ядро",
		healthy: "Стабильно",
		degraded: "Напряжение",
		fileName: "Имя узла",
		size: "Размер",
		copied: "Скопировано",
		explorer: "Проводник",
		fromYou: "с вашего паспорта",
		toYou: "на паспорт",
		rest: "Сброс демо",
		restDone: "Слой сброшен",
		saveName: "Записать паспорт",
		saved: "Паспорт обновлён",
		firstTx: "Первая операция",
		yearFree: "года — без комиссии",
		continue: "Продолжить",
		skip: "Пропустить",
		seal: "Печать",
		watchword: "Ни одного лишнего выезда. Ни одного слепого моста."
	},
	en: {
		app: "OMNIXIUS",
		kicker: "Sovereign layer",
		deck: "Deck",
		map: "BOLH",
		agora: "Agora",
		guardio: "Guardio",
		vault: "Vault",
		nexus: "Nexus",
		repo: "Repositorium",
		chain: "Omni-L1",
		notepad: "Notepad",
		mvs: "MVS",
		president: "President",
		passport: "Passport",
		search: "Search the layer",
		sos: "SOS",
		lang: "RU",
		operator: "Operator",
		citizen: "Citizen",
		pro: "Pro",
		verified: "Credential",
		identity: "Identity",
		unverified: "Unverified",
		trust: "Trust",
		height: "Height",
		peers: "Peers",
		pqc: "PQC",
		oxi: "OXI",
		nearby: "In field",
		contracts: "Contracts",
		threats: "Threats",
		live: "Live spine",
		valentine: "14 Feb protocol — first operation of the year carries no fee",
		valentineOn: "Demo 14 Feb",
		bootA: "Raising the sovereign layer",
		bootB: "Cryptography · consensus · clearance",
		enter: "Enter",
		compass: "Compass",
		dest: "Heading",
		noDest: "No target",
		agents: "Agents",
		presidentIdle: "Guardian quiet",
		presidentAlert: "Guardian engaged",
		mvsIdle: "MVS standing by",
		mvsOpen: "Open channel",
		field: "Field",
		capital: "Capital",
		people: "People",
		intel: "Intelligence",
		more: "More",
		toolsHave: "Has tools",
		toolsNeed: "Needs tools",
		toolsAny: "Any logistics",
		match: "Match",
		mismatch: "Mismatch",
		lock: "Lock contract",
		dispatch: "Dispatch",
		offerBlocked: "No credential — certified work is closed",
		hidden: "Route hidden",
		approx: "Cell",
		available: "On call",
		busy: "Busy",
		armed: "Armed",
		unarmed: "Unarmed",
		response: "ETA",
		min: "min",
		rate: "Rate",
		buy: "Buy",
		lease: "Lease",
		post: "Publish",
		like: "Mark",
		upload: "Write node",
		shards: "Shards",
		encrypted: "Cipher",
		send: "Send",
		zk: "ZK",
		bridge: "Bridge",
		firstFree: "Fee 0 — Valentine",
		plan: "Build plan",
		notePh: "A thought, a task, a risk…",
		mvsPh: "Ask MVS — markets, clearance, translation",
		scan: "Scan the layer",
		apply: "Accept patch",
		dismiss: "Dismiss",
		dispute: "Black box",
		resolveA: "For the client",
		resolveB: "For the agent",
		clearanceWall: "Operator clearance only",
		wallCopy: "President is the local core guardian. Citizens speak with MVS. Switch clearance in the passport to enter.",
		switchOp: "Become operator",
		save: "Save",
		name: "Name",
		handle: "Handle",
		languages: "Languages",
		myTools: "Tools",
		requestId: "Request identity",
		requestCred: "Submit credential",
		balance: "Balances",
		spark: "OXI / 30 days",
		genesis: "Genesis",
		mempool: "Mempool",
		from: "From",
		to: "To",
		amount: "Amount",
		memo: "Memo",
		chainLabel: "Chain",
		fee: "Fee",
		confirm: "Confirm",
		empty: "Empty",
		emptyNotes: "Write a thought — MVS will turn it into a plan.",
		emptyChat: "MVS is silent until you speak.",
		emptyContracts: "No live contracts.",
		risk: "Risk note",
		onSite: "On site",
		stream: "Agent channel",
		close: "Close",
		cancel: "Cancel",
		city: "City",
		theatre: "Theatre",
		europe: "Europe & Caucasus",
		africa: "Gulf & Africa",
		asia: "Asia-Pacific",
		americas: "Americas",
		goods: "Goods",
		land: "Land",
		auto: "Auto",
		service: "Service",
		all: "All",
		experts: "Masters",
		guards: "Guards",
		listings: "Lots",
		files: "Nodes",
		aiDown: "AI is unavailable. Try again.",
		thinking: "Thinking…",
		speak: "Voice",
		patched: "Patch accepted",
		dismissed: "Dismissed",
		lockedOk: "Contract locked",
		dispatched: "Guard rolling",
		sosSent: "SOS accepted — nearest guard locked",
		posted: "Published",
		uploaded: "Node written",
		sent: "Transaction in block",
		needClearance: "Clearance insufficient",
		hours: "hours",
		kind: "Kind",
		status: "Status",
		locked: "Locked",
		in_field: "In field",
		disputed: "Disputed",
		resolved: "Resolved",
		cancelled: "Cancelled",
		watch: "Watch",
		elevated: "Elevated",
		critical: "Critical",
		peersN: "4 shards · 18 nodes",
		deckLede: "Layer health, agents, and nearest obligations on one plane.",
		mapLede: "People, land, autos, and guards. Tool filters cut empty trips.",
		agoraLede: "One market: lots, leases, autos, and field work.",
		guardLede: "Guard parameters lock into a contract in one tick.",
		vaultLede: "Treasury, bridges, and confidential transfers.",
		nexusLede: "The layer feed — dispatches, not a storefront.",
		repoLede: "Sharded storage in a post-quantum envelope.",
		chainLede: "Omni-L1: PQC blocks, ZK memos, BTC / ETH / SOL / BSC wraps.",
		noteLede: "A thought becomes a plan with steps and blockers.",
		mvsLede: "Minister of Foreign Affairs: clearance, translation, cautious advice.",
		presLede: "Invisible core guardian. Patches move only on your word.",
		passLede: "One passport across every module. Clearance is not a diploma.",
		self: "You",
		none: "None",
		identityLong: "Identity",
		credentialLong: "Credential / Pro",
		citizenLong: "Citizen",
		proLong: "Pro",
		operatorLong: "Operator",
		lattice: "Trust lattice",
		latticeCopy: "The passport binds field, treasury, and guard. One trust score.",
		newListing: "New lot",
		title: "Title",
		price: "Price",
		publishLot: "List",
		recipient: "Address / handle",
		omni: "OMNI",
		btc: "BTC",
		eth: "ETH",
		sol: "SOL",
		bsc: "BSC",
		confidential: "Hide route",
		applyPatch: "Apply",
		proposed: "Proposed",
		applied: "In core",
		openThreats: "Open",
		lastBlocks: "Latest blocks",
		bridges: "Bridges",
		noMatch: "No masters for this filter",
		withTools: "With tools",
		withoutTools: "Without tools",
		youHave: "You have tools",
		youNeed: "Bring tools to you",
		logistics: "Logistics",
		optimal: "Optimal",
		redundant: "Redundant",
		blocked: "Cannot roll",
		commandHint: "⌘K / Ctrl+K",
		modules: "Modules",
		noResults: "Nothing",
		simAttack: "Simulate attack",
		voiceAlert: "Voice alert",
		patchLog: "Patch log",
		health: "Core",
		healthy: "Stable",
		degraded: "Strain",
		fileName: "Node name",
		size: "Size",
		copied: "Copied",
		explorer: "Explorer",
		fromYou: "from your passport",
		toYou: "to the passport",
		rest: "Reset demo",
		restDone: "Layer reset",
		saveName: "Write passport",
		saved: "Passport updated",
		firstTx: "First operation",
		yearFree: "of the year — no fee",
		continue: "Continue",
		skip: "Skip",
		seal: "Seal",
		watchword: "No empty trips. No blind bridges."
	}
};
function copy(locale) {
	return dict[locale];
}
function oxi(n, digits = 2) {
	return n.toLocaleString("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function ago(ts, locale) {
	return formatDistanceToNow(ts, {
		addSuffix: true,
		locale: locale === "ru" ? ru : enUS
	});
}
function hashOf(input, len = 16) {
	let h = 2166136261;
	for (let i = 0; i < input.length; i++) {
		h ^= input.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return `0x${((h >>> 0).toString(16).padStart(8, "0") + ((h ^ 2779096485) >>> 0).toString(16).padStart(8, "0")).slice(0, len)}`;
}
function uid(prefix) {
	const n = Math.random().toString(36).slice(2, 8);
	return `${prefix}_${Date.now().toString(36).slice(-4)}${n}`;
}
function isValentine(demo, now = /* @__PURE__ */ new Date()) {
	return demo || now.getMonth() === 1 && now.getDate() === 14;
}
function bearingTo(from, to) {
	const φ1 = from.lat * Math.PI / 180;
	const φ2 = to.lat * Math.PI / 180;
	const Δλ = (to.lng - from.lng) * Math.PI / 180;
	const y = Math.sin(Δλ) * Math.cos(φ2);
	const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
	return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
var GENESIS = Date.parse("2026-08-20T08:00:00.000Z");
var cities = [
	{
		id: "lisbon",
		name: "Lisbon",
		country: "Portugal",
		countryRu: "Португалия",
		lat: 38.72,
		lng: -9.14,
		theatre: "europe"
	},
	{
		id: "marseille",
		name: "Marseille",
		country: "France",
		countryRu: "Франция",
		lat: 43.3,
		lng: 5.37,
		theatre: "europe"
	},
	{
		id: "zurich",
		name: "Zürich",
		country: "Switzerland",
		countryRu: "Швейцария",
		lat: 47.37,
		lng: 8.54,
		theatre: "europe"
	},
	{
		id: "tallinn",
		name: "Tallinn",
		country: "Estonia",
		countryRu: "Эстония",
		lat: 59.44,
		lng: 24.75,
		theatre: "europe"
	},
	{
		id: "tbilisi",
		name: "Tbilisi",
		country: "Georgia",
		countryRu: "Грузия",
		lat: 41.69,
		lng: 44.83,
		theatre: "europe"
	},
	{
		id: "dubai",
		name: "Dubai",
		country: "UAE",
		countryRu: "ОАЭ",
		lat: 25.2,
		lng: 55.27,
		theatre: "africa"
	},
	{
		id: "lagos",
		name: "Lagos",
		country: "Nigeria",
		countryRu: "Нигерия",
		lat: 6.52,
		lng: 3.38,
		theatre: "africa"
	},
	{
		id: "kyoto",
		name: "Kyoto",
		country: "Japan",
		countryRu: "Япония",
		lat: 35.01,
		lng: 135.77,
		theatre: "asia"
	},
	{
		id: "singapore",
		name: "Singapore",
		country: "Singapore",
		countryRu: "Сингапур",
		lat: 1.35,
		lng: 103.82,
		theatre: "asia"
	},
	{
		id: "ba",
		name: "Buenos Aires",
		country: "Argentina",
		countryRu: "Аргентина",
		lat: -34.6,
		lng: -58.38,
		theatre: "americas"
	}
];
cities[2];
var experts = [
	{
		id: "ex_nika",
		name: "Nika Beridze",
		craft: "Stone restoration",
		craftRu: "Реставрация камня",
		cityId: "tbilisi",
		verification: "credential",
		hasTools: true,
		rateOxi: 86,
		rating: 4.9,
		reviews: 41,
		languages: [
			"ka",
			"ru",
			"en"
		],
		bio: "Facades, lime mortar, old courtyards. Brings full kit.",
		bioRu: "Фасады, известковый раствор, дворы. Полный комплект с собой.",
		available: true
	},
	{
		id: "ex_amara",
		name: "Amara Okonkwo",
		craft: "Field electrics",
		craftRu: "Полевая электрика",
		cityId: "lagos",
		verification: "credential",
		hasTools: true,
		rateOxi: 74,
		rating: 4.8,
		reviews: 63,
		languages: ["en", "yo"],
		bio: "Grid drops, cold rooms, night work. Tools on the van.",
		bioRu: "Вводы, холодильные камеры, ночные работы. Инструмент в фургоне.",
		available: true
	},
	{
		id: "ex_luca",
		name: "Luca Moretti",
		craft: "Auto diagnostics",
		craftRu: "Автодиагностика",
		cityId: "marseille",
		verification: "credential",
		hasTools: true,
		rateOxi: 92,
		rating: 4.7,
		reviews: 28,
		languages: [
			"fr",
			"it",
			"en"
		],
		bio: "Diesel and marine electrics. Shop or roadside.",
		bioRu: "Дизель и судовая электрика. Цех или обочина.",
		available: true
	},
	{
		id: "ex_yuki",
		name: "Yuki Nakamura",
		craft: "Land survey",
		craftRu: "Землемерие",
		cityId: "kyoto",
		verification: "credential",
		hasTools: false,
		rateOxi: 110,
		rating: 4.9,
		reviews: 19,
		languages: ["ja", "en"],
		bio: "Boundary and terrace work. Client provides total station.",
		bioRu: "Межи и террасы. Тахеометр — на стороне заказчика.",
		available: true
	},
	{
		id: "ex_sofia",
		name: "Sofia Reyes",
		craft: "Agronomy",
		craftRu: "Агрономия",
		cityId: "ba",
		verification: "identity",
		hasTools: false,
		rateOxi: 55,
		rating: 4.6,
		reviews: 12,
		languages: ["es", "en"],
		bio: "Soil advice. No diploma on file — cannot certify.",
		bioRu: "Почвы. Диплома в слое нет — сертифицировать нельзя.",
		available: true
	},
	{
		id: "ex_henrik",
		name: "Henrik Voss",
		craft: "Security architecture",
		craftRu: "Архитектура охраны",
		cityId: "zurich",
		verification: "credential",
		hasTools: true,
		rateOxi: 140,
		rating: 4.9,
		reviews: 22,
		languages: [
			"de",
			"en",
			"fr"
		],
		bio: "Site surveys for firms that later lock Guardio contracts.",
		bioRu: "Обследование объектов перед контрактом Guardio.",
		available: true
	},
	{
		id: "ex_layla",
		name: "Layla Hassan",
		craft: "Field translation",
		craftRu: "Полевой перевод",
		cityId: "dubai",
		verification: "credential",
		hasTools: false,
		rateOxi: 68,
		rating: 4.8,
		reviews: 37,
		languages: [
			"ar",
			"en",
			"fr",
			"ru"
		],
		bio: "On-site language for contracts and disputes.",
		bioRu: "Язык на месте для контрактов и споров.",
		available: true
	},
	{
		id: "ex_tomasz",
		name: "Tomasz Kowal",
		craft: "Carpentry",
		craftRu: "Столярка",
		cityId: "lisbon",
		verification: "none",
		hasTools: true,
		rateOxi: 48,
		rating: 4.4,
		reviews: 7,
		languages: [
			"pl",
			"pt",
			"en"
		],
		bio: "Joinery. Unverified — cannot offer certified Pro work.",
		bioRu: "Столярка. Без допуска — сертифицированный Pro закрыт.",
		available: true
	}
];
var guards = [
	{
		id: "g_aegis",
		firm: "Aegis Alpine",
		cityId: "zurich",
		responseMin: 6,
		armed: true,
		available: true,
		rateOxi: 220,
		units: 4
	},
	{
		id: "g_night",
		firm: "Nightwatch",
		cityId: "tbilisi",
		responseMin: 8,
		armed: true,
		available: true,
		rateOxi: 95,
		units: 6
	},
	{
		id: "g_sable",
		firm: "Sable Line",
		cityId: "lagos",
		responseMin: 12,
		armed: true,
		available: true,
		rateOxi: 110,
		units: 5
	},
	{
		id: "g_harbor",
		firm: "Harbor Guard",
		cityId: "singapore",
		responseMin: 5,
		armed: false,
		available: true,
		rateOxi: 160,
		units: 3
	},
	{
		id: "g_rio",
		firm: "Río Sur",
		cityId: "ba",
		responseMin: 14,
		armed: false,
		available: true,
		rateOxi: 70,
		units: 4
	}
];
var listings = [
	{
		id: "l_olive",
		title: "2.4 ha olive terrace",
		titleRu: "Оливковая терраса 2,4 га",
		kind: "land",
		cityId: "marseille",
		priceOxi: 18400,
		seller: "Maison Calvet",
		hiddenRoute: true,
		blurb: "South slope, stone walls, well. Exact gate hidden until lock.",
		blurbRu: "Южный склон, каменные стены, колодец. Ворота скрыты до контракта."
	},
	{
		id: "l_cruiser",
		title: "Land Cruiser 2018, 86k",
		titleRu: "Land Cruiser 2018, 86 тыс.",
		kind: "auto",
		cityId: "tbilisi",
		priceOxi: 4200,
		seller: "Kartli Motors",
		hiddenRoute: false,
		blurb: "Shop inspection on file. Pickup in Nadzaladevi.",
		blurbRu: "Осмотр цеха в деле. Выдача в Надзаладеви."
	},
	{
		id: "l_cold",
		title: "Cold-store bay, 90 days",
		titleRu: "Холодный отсек, 90 дней",
		kind: "land",
		cityId: "dubai",
		priceOxi: 2600,
		seller: "Qasr Logistics",
		hiddenRoute: true,
		blurb: "Shared dock. Address in ZK cell.",
		blurbRu: "Общий док. Адрес в ZK-клетке."
	},
	{
		id: "l_watch",
		title: "Movement kit, 1920s",
		titleRu: "Механизм, 1920-е",
		kind: "goods",
		cityId: "zurich",
		priceOxi: 880,
		seller: "Atelier Brugg",
		hiddenRoute: false,
		blurb: "Unrestored, papers in Repositorium.",
		blurbRu: "Без реставрации, бумаги в Repositorium."
	},
	{
		id: "l_studio",
		title: "Studio lease, 6 months",
		titleRu: "Студия, 6 месяцев",
		kind: "land",
		cityId: "lisbon",
		priceOxi: 1900,
		seller: "Alfama Hold",
		hiddenRoute: false,
		blurb: "Third floor, no lift, river noise.",
		blurbRu: "Третий этаж, без лифта, шум реки."
	},
	{
		id: "l_van",
		title: "Workshop van, diesel",
		titleRu: "Мастерская-фургон, дизель",
		kind: "auto",
		cityId: "lagos",
		priceOxi: 3100,
		seller: "Apapa Yard",
		hiddenRoute: false,
		blurb: "Racked interior, night lights.",
		blurbRu: "Стеллажи, ночной свет."
	},
	{
		id: "l_cedar",
		title: "Cedar lot, kiln-dried",
		titleRu: "Партия кедра, камерная сушка",
		kind: "goods",
		cityId: "kyoto",
		priceOxi: 640,
		seller: "Kitayama Wood",
		hiddenRoute: false,
		blurb: "For joiners who bring their own tools.",
		blurbRu: "Для столяров со своим инструментом."
	},
	{
		id: "l_survey",
		title: "Boundary recertify",
		titleRu: "Переаттестация межи",
		kind: "service",
		cityId: "kyoto",
		priceOxi: 320,
		seller: "Yuki Nakamura",
		hiddenRoute: true,
		blurb: "Pro survey. Client supplies station.",
		blurbRu: "Pro-съёмка. Станцию даёт заказчик."
	}
];
var posts = [
	{
		id: "p1",
		author: "Nightwatch",
		cityId: "tbilisi",
		body: "Two units free after 21:00. Old town only.",
		bodyRu: "Два экипажа свободны после 21:00. Только старый город.",
		ts: GENESIS + 72e6,
		likes: 14
	},
	{
		id: "p2",
		author: "Nika Beridze",
		cityId: "tbilisi",
		body: "Lime batch curing. Can take a courtyard Friday.",
		bodyRu: "Известь набирает. Двор могу взять в пятницу.",
		ts: GENESIS + 1008e5,
		likes: 9
	},
	{
		id: "p3",
		author: "Maison Calvet",
		cityId: "marseille",
		body: "Olive terrace listed. Gate stays in ZK until lock.",
		bodyRu: "Терраса выставлена. Ворота в ZK до контракта.",
		ts: GENESIS + 144e6,
		likes: 21
	},
	{
		id: "p4",
		author: "Harbor Guard",
		cityId: "singapore",
		body: "Unarmed dock watch, five-minute roll.",
		bodyRu: "Безоружный дозор на причале, выезд пять минут.",
		ts: GENESIS + 1584e5,
		likes: 6
	},
	{
		id: "p5",
		author: "Amara Okonkwo",
		cityId: "lagos",
		body: "Cold-room compressor recovered. Invoice in Omni-L1.",
		bodyRu: "Компрессор камеры поднят. Счёт в Omni-L1.",
		ts: GENESIS + 18e7,
		likes: 17
	}
];
var files = [
	{
		id: "f1",
		name: "credential-nika.pq",
		sizeKb: 240,
		shards: 4,
		encrypted: true,
		pqc: true,
		ts: GENESIS + 288e5
	},
	{
		id: "f2",
		name: "calvet-survey.zk",
		sizeKb: 1800,
		shards: 6,
		encrypted: true,
		pqc: true,
		ts: GENESIS + 432e5
	},
	{
		id: "f3",
		name: "harbor-sop.md",
		sizeKb: 48,
		shards: 3,
		encrypted: true,
		pqc: true,
		ts: GENESIS + 648e5
	}
];
var seedTxs = [
	{
		id: hashOf("tx1"),
		from: "Maison Calvet",
		to: "treasury",
		amount: 120,
		asset: "OXI",
		chain: "omni",
		zk: true,
		ts: GENESIS + 36e6,
		fee: .4,
		memo: "listing bond"
	},
	{
		id: hashOf("tx2"),
		from: "bridge:eth",
		to: "@operator",
		amount: 1.22,
		asset: "WETH",
		chain: "eth",
		zk: false,
		ts: GENESIS + 504e5,
		fee: .002
	},
	{
		id: hashOf("tx3"),
		from: "Amara Okonkwo",
		to: "Qasr Logistics",
		amount: 74,
		asset: "OXI",
		chain: "omni",
		zk: false,
		ts: GENESIS + 792e5,
		fee: .2
	},
	{
		id: hashOf("tx4"),
		from: "bridge:btc",
		to: "@operator",
		amount: .084,
		asset: "WBTC",
		chain: "btc",
		zk: true,
		ts: GENESIS + 936e5,
		fee: 1e-4
	},
	{
		id: hashOf("tx5"),
		from: "Nightwatch",
		to: "treasury",
		amount: 18,
		asset: "OXI",
		chain: "omni",
		zk: false,
		ts: GENESIS + 108e6,
		fee: .1,
		memo: "bond"
	}
];
var genesisBlocks = Array.from({ length: 8 }, (_, i) => {
	const height = 184220 + i;
	const ts = GENESIS + i * 8e3 + 1728e5;
	return {
		height,
		hash: hashOf(`block-${height}`),
		txCount: 2 + i % 4,
		ts,
		pqc: true
	};
});
var seedThreats = [{
	id: "th1",
	level: "watch",
	title: "Bridge wrapper lag on BSC",
	titleRu: "Лаг обёртки моста BSC",
	detail: "Proof window stretched to 42s. No funds at risk. Watch only.",
	detailRu: "Окно доказательства 42 с. Средства не затронуты. Только наблюдение.",
	ts: GENESIS + 1656e5,
	status: "open"
}, {
	id: "th2",
	level: "elevated",
	title: "Replay on Guardio parameter channel",
	titleRu: "Повтор на канале параметров Guardio",
	detail: "Two duplicate lock attempts from a stale client. Dropped.",
	detailRu: "Два повторных закрытия со старого клиента. Отброшены.",
	ts: GENESIS + 1764e5,
	status: "open"
}];
var seedPatches = [{
	id: "pa1",
	title: "Raise BSC proof window to 60s",
	titleRu: "Поднять окно BSC до 60 с",
	detail: "Policy patch. No binary rewrite. Operator must accept.",
	detailRu: "Политический патч. Без переписи бинаря. Нужно слово оператора.",
	ts: GENESIS + 1692e5,
	applied: false
}];
var oxiSpark = [
	1,
	1.01,
	.99,
	1.02,
	1.04,
	1.03,
	1.06,
	1.05,
	1.08,
	1.07,
	1.09,
	1.12,
	1.1,
	1.14,
	1.13,
	1.16,
	1.18,
	1.17,
	1.19,
	1.22,
	1.2,
	1.21,
	1.24,
	1.23,
	1.25,
	1.27,
	1.26,
	1.28,
	1.3,
	1.29
];
var defaultPassport = {
	name: "Alex Moreau",
	handle: "operator",
	clearance: "operator",
	verification: "credential",
	trust: 86,
	languages: [
		"fr",
		"en",
		"ru"
	],
	tools: ["van", "multimeter"],
	hasTools: true,
	oxi: 12480,
	wbtc: .084,
	weth: 1.22,
	sol: 18.4,
	bnb: 42,
	valentineUsed: false
};
var HOME = {
	lat: 47.37,
	lng: 8.54
};
var KEY = "omnixius.v1";
var VER = 1;
function cityById(id) {
	return cities.find((c) => c.id === id);
}
function persistSlice(s) {
	return {
		v: VER,
		passport: s.passport,
		extraListings: s.extraListings,
		extraPosts: s.extraPosts,
		contracts: s.contracts,
		files: s.files,
		extraTxs: s.extraTxs,
		notes: s.notes,
		mvs: s.mvs,
		threats: s.threats,
		patches: s.patches,
		locale: s.locale,
		bootSeen: s.bootSeen,
		valentineDemo: s.valentineDemo,
		liked: s.liked
	};
}
function load() {
	if (typeof window === "undefined") return null;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (parsed.v !== VER) return null;
		return parsed;
	} catch {
		return null;
	}
}
function save(s) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(KEY, JSON.stringify(persistSlice(s)));
	} catch {}
}
var initial = {
	hydrated: false,
	locale: "ru",
	bootSeen: false,
	valentineDemo: false,
	passport: { ...defaultPassport },
	extraListings: [],
	extraPosts: [],
	contracts: [],
	files: [...files],
	extraTxs: [],
	notes: [],
	mvs: [],
	threats: [...seedThreats],
	patches: [...seedPatches],
	liked: [],
	blocks: [...genesisBlocks],
	selectedCityId: "zurich",
	logistics: "any",
	listingKind: "all"
};
function feeFor(amount, valentine, used) {
	if (valentine && !used) return 0;
	return Math.max(.05, amount * .002);
}
var usePlatform = create((set, get) => ({
	...initial,
	hydrate: () => {
		const loaded = load();
		if (!loaded) {
			set({ hydrated: true });
			return;
		}
		set({
			hydrated: true,
			locale: loaded.locale ?? "ru",
			bootSeen: loaded.bootSeen ?? false,
			valentineDemo: loaded.valentineDemo ?? false,
			passport: {
				...defaultPassport,
				...loaded.passport
			},
			extraListings: loaded.extraListings ?? [],
			extraPosts: loaded.extraPosts ?? [],
			contracts: loaded.contracts ?? [],
			files: loaded.files && loaded.files.length ? loaded.files : [...files],
			extraTxs: loaded.extraTxs ?? [],
			notes: loaded.notes ?? [],
			mvs: loaded.mvs ?? [],
			threats: loaded.threats && loaded.threats.length ? loaded.threats : [...seedThreats],
			patches: loaded.patches && loaded.patches.length ? loaded.patches : [...seedPatches],
			liked: loaded.liked ?? []
		});
	},
	setLocale: (l) => {
		set({ locale: l });
		save(get());
	},
	setBootSeen: () => {
		set({ bootSeen: true });
		save(get());
	},
	setValentineDemo: (v) => {
		set({ valentineDemo: v });
		save(get());
	},
	setPassport: (p) => {
		set({ passport: {
			...get().passport,
			...p
		} });
		save(get());
	},
	setClearance: (c) => {
		set({ passport: {
			...get().passport,
			clearance: c
		} });
		save(get());
	},
	setVerification: (v) => {
		set({ passport: {
			...get().passport,
			verification: v
		} });
		save(get());
	},
	setSelectedCity: (id) => set({ selectedCityId: id }),
	setLogistics: (l) => set({ logistics: l }),
	setListingKind: (k) => set({ listingKind: k }),
	likePost: (id) => {
		set({ liked: get().liked.includes(id) ? get().liked.filter((x) => x !== id) : [...get().liked, id] });
		save(get());
	},
	addPost: (body) => {
		const p = get().passport;
		set({ extraPosts: [{
			id: uid("p"),
			author: p.name,
			cityId: "zurich",
			body,
			bodyRu: body,
			ts: Date.now(),
			likes: 0
		}, ...get().extraPosts] });
		save(get());
	},
	addListing: (input) => {
		const v = get().passport.verification;
		if (input.kind === "service" && v !== "credential") return {
			ok: false,
			reason: "offerBlocked"
		};
		set({ extraListings: [{
			id: uid("l"),
			title: input.title,
			titleRu: input.title,
			kind: input.kind,
			cityId: input.cityId,
			priceOxi: input.priceOxi,
			seller: get().passport.name,
			hiddenRoute: input.hiddenRoute,
			blurb: input.title,
			blurbRu: input.title
		}, ...get().extraListings] });
		save(get());
		return { ok: true };
	},
	lockExpert: (expertId, hours) => {
		const ex = experts.find((e) => e.id === expertId);
		if (!ex) return {
			ok: false,
			reason: "missing"
		};
		if (ex.verification !== "credential") return {
			ok: false,
			reason: "offerBlocked"
		};
		const amount = ex.rateOxi * hours;
		const valentine = isValentine(get().valentineDemo);
		const free = valentine && !get().passport.valentineUsed;
		const fee = feeFor(amount, valentine, get().passport.valentineUsed);
		if (get().passport.oxi < amount + fee) return {
			ok: false,
			reason: "funds"
		};
		const id = uid("c");
		set({
			contracts: [{
				id,
				kind: "service",
				title: ex.craft,
				counterparty: ex.name,
				cityId: ex.cityId,
				amount,
				status: "locked",
				ts: Date.now(),
				hiddenRoute: false
			}, ...get().contracts],
			passport: {
				...get().passport,
				oxi: get().passport.oxi - amount - fee,
				valentineUsed: get().passport.valentineUsed || free,
				trust: Math.min(99, get().passport.trust + 1)
			},
			extraTxs: [{
				id: hashOf(id),
				from: `@${get().passport.handle}`,
				to: ex.name,
				amount,
				asset: "OXI",
				chain: "omni",
				zk: false,
				ts: Date.now(),
				fee,
				memo: free ? "valentine" : "service"
			}, ...get().extraTxs],
			selectedCityId: ex.cityId
		});
		save(get());
		return {
			ok: true,
			id,
			free
		};
	},
	lockListing: (listingId) => {
		const lot = [...get().extraListings, ...listings].find((l) => l.id === listingId);
		if (!lot) return {
			ok: false,
			reason: "missing"
		};
		const amount = lot.priceOxi;
		const valentine = isValentine(get().valentineDemo);
		const free = valentine && !get().passport.valentineUsed;
		const fee = feeFor(amount, valentine, get().passport.valentineUsed);
		if (get().passport.oxi < amount + fee) return {
			ok: false,
			reason: "funds"
		};
		const id = uid("c");
		set({
			contracts: [{
				id,
				kind: lot.kind === "land" ? "lease" : lot.kind === "service" ? "service" : "trade",
				title: lot.title,
				counterparty: lot.seller,
				cityId: lot.cityId,
				amount,
				status: "locked",
				ts: Date.now(),
				hiddenRoute: lot.hiddenRoute
			}, ...get().contracts],
			passport: {
				...get().passport,
				oxi: get().passport.oxi - amount - fee,
				valentineUsed: get().passport.valentineUsed || free,
				trust: Math.min(99, get().passport.trust + 1)
			},
			extraTxs: [{
				id: hashOf(id),
				from: `@${get().passport.handle}`,
				to: lot.seller,
				amount,
				asset: "OXI",
				chain: "omni",
				zk: lot.hiddenRoute,
				ts: Date.now(),
				fee,
				memo: free ? "valentine" : lot.kind
			}, ...get().extraTxs],
			selectedCityId: lot.cityId
		});
		save(get());
		return {
			ok: true,
			id,
			free
		};
	},
	dispatchGuard: (guardId, sos) => {
		const g = guards.find((x) => x.id === guardId);
		if (!g) return {
			ok: false,
			reason: "missing"
		};
		const amount = g.rateOxi;
		const valentine = isValentine(get().valentineDemo);
		const free = valentine && !get().passport.valentineUsed;
		const fee = feeFor(amount, valentine, get().passport.valentineUsed);
		if (get().passport.oxi < amount + fee) return {
			ok: false,
			reason: "funds"
		};
		const id = uid("c");
		set({
			contracts: [{
				id,
				kind: "guard",
				title: sos ? `SOS · ${g.firm}` : g.firm,
				counterparty: g.firm,
				cityId: g.cityId,
				amount,
				status: "in_field",
				ts: Date.now(),
				hiddenRoute: true,
				notes: sos ? "sos" : void 0
			}, ...get().contracts],
			passport: {
				...get().passport,
				oxi: get().passport.oxi - amount - fee,
				valentineUsed: get().passport.valentineUsed || free,
				trust: Math.min(99, get().passport.trust + 1)
			},
			extraTxs: [{
				id: hashOf(id),
				from: `@${get().passport.handle}`,
				to: g.firm,
				amount,
				asset: "OXI",
				chain: "omni",
				zk: true,
				ts: Date.now(),
				fee,
				memo: sos ? "sos" : "guard"
			}, ...get().extraTxs],
			selectedCityId: g.cityId
		});
		save(get());
		return {
			ok: true,
			id,
			free
		};
	},
	setContractStatus: (id, status) => {
		set({ contracts: get().contracts.map((c) => c.id === id ? {
			...c,
			status
		} : c) });
		save(get());
	},
	uploadFile: (name, sizeKb) => {
		set({ files: [{
			id: uid("f"),
			name,
			sizeKb,
			shards: 4,
			encrypted: true,
			pqc: true,
			ts: Date.now()
		}, ...get().files] });
		save(get());
	},
	sendTx: (input) => {
		const amount = input.amount;
		const valentine = isValentine(get().valentineDemo);
		const free = valentine && !get().passport.valentineUsed;
		const fee = input.asset === "OXI" ? feeFor(amount, valentine, get().passport.valentineUsed) : amount * .001;
		const p = get().passport;
		if (input.asset === "OXI" && p.oxi < amount + fee) return {
			ok: false,
			reason: "funds"
		};
		const id = hashOf(uid("tx"));
		const tx = {
			id,
			from: `@${p.handle}`,
			to: input.to,
			amount,
			asset: input.asset,
			chain: input.chain,
			zk: input.zk,
			ts: Date.now(),
			fee,
			memo: input.memo ?? (free ? "valentine" : void 0)
		};
		const next = {
			...p,
			valentineUsed: p.valentineUsed || free && input.asset === "OXI"
		};
		if (input.asset === "OXI") next.oxi = p.oxi - amount - fee;
		if (input.asset === "WBTC") next.wbtc = p.wbtc - amount;
		if (input.asset === "WETH") next.weth = p.weth - amount;
		if (input.asset === "SOL") next.sol = p.sol - amount;
		if (input.asset === "BNB") next.bnb = p.bnb - amount;
		set({
			extraTxs: [tx, ...get().extraTxs],
			passport: next
		});
		save(get());
		return {
			ok: true,
			id,
			free
		};
	},
	addNote: (raw, plan) => {
		const id = uid("n");
		set({ notes: [{
			id,
			raw,
			plan,
			ts: Date.now()
		}, ...get().notes] });
		save(get());
		return id;
	},
	setNotePlan: (id, plan) => {
		set({ notes: get().notes.map((n) => n.id === id ? {
			...n,
			plan
		} : n) });
		save(get());
	},
	pushMvs: (msg) => {
		set({ mvs: [...get().mvs, msg] });
		save(get());
	},
	tickChain: () => {
		const blocks = get().blocks;
		const last = blocks[blocks.length - 1];
		if (!last) return;
		const height = last.height + 1;
		const b = {
			height,
			hash: hashOf(`block-${height}-${Date.now()}`),
			txCount: 1 + height % 5,
			ts: Date.now(),
			pqc: true
		};
		set({ blocks: [...blocks, b].slice(-24) });
	},
	applyPatch: (id) => {
		set({
			patches: get().patches.map((p) => p.id === id ? {
				...p,
				applied: true
			} : p),
			threats: get().threats.map((t) => t.status === "open" && t.level !== "critical" ? {
				...t,
				status: "patched"
			} : t)
		});
		save(get());
	},
	dismissThreat: (id) => {
		set({ threats: get().threats.map((t) => t.id === id ? {
			...t,
			status: "dismissed"
		} : t) });
		save(get());
	},
	simulateAttack: () => {
		const threat = {
			id: uid("th"),
			level: "critical",
			title: "Unsigned state transition on shard 2",
			titleRu: "Неподписанный переход состояния, шард 2",
			detail: "President halted the transition. A policy patch is queued. No binary rewrite.",
			detailRu: "Президент остановил переход. Политический патч в очереди. Без переписи бинаря.",
			ts: Date.now(),
			status: "open"
		};
		const patch = {
			id: uid("pa"),
			title: "Require dual signature on shard 2 commits",
			titleRu: "Двойная подпись на коммитах шарда 2",
			detail: "Policy only. Operator must accept. Core will not self-rewrite.",
			detailRu: "Только политика. Нужно слово оператора. Ядро само себя не переписывает.",
			ts: Date.now(),
			applied: false
		};
		set({
			threats: [threat, ...get().threats],
			patches: [patch, ...get().patches]
		});
		save(get());
	},
	resetDemo: () => {
		if (typeof window !== "undefined") localStorage.removeItem(KEY);
		set({
			...initial,
			hydrated: true,
			blocks: [...genesisBlocks]
		});
	}
}));
function mergeListings(extra) {
	return [...extra, ...listings];
}
function mergePosts(extra) {
	return [...extra, ...posts].sort((a, b) => b.ts - a.ts);
}
function mergeTxs(extra) {
	return [...extra, ...seedTxs].sort((a, b) => b.ts - a.ts);
}
function openThreats(s) {
	return s.threats.filter((t) => t.status === "open");
}
function cityName(id) {
	return cityById(id)?.name ?? id;
}
//#endregion
export { oxiSpark as _, cityName as a, experts as c, listings as d, mergeListings as f, oxi as g, openThreats as h, cities as i, guards as l, mergeTxs as m, ago as n, cn as o, mergePosts as p, bearingTo as r, copy as s, HOME as t, isValentine as u, uid as v, usePlatform as y };
