import { g as oxi, m as mergeTxs, n as ago, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Stat, n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chain-DuXktmdk.js
var import_jsx_runtime = require_jsx_runtime();
function Chain() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const blocks = usePlatform((s) => s.blocks);
	const extraTxs = usePlatform((s) => s.extraTxs);
	const txs = mergeTxs(extraTxs).slice(0, 12);
	const last = blocks[blocks.length - 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.capital,
			title: t.chain,
			lede: t.chainLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.height,
					value: last?.height.toLocaleString() ?? "—",
					hint: t.pqc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.peers,
					value: t.peersN
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.health,
					value: t.healthy
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.lastBlocks
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: [...blocks].reverse().slice(0, 8).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex min-h-12 items-center justify-between gap-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-primary",
						children: b.hash
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"#",
							b.height,
							" · ",
							b.txCount,
							" · ",
							ago(b.ts, locale)
						]
					})] }), b.pqc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "success",
						children: t.pqc
					}) : null]
				}, b.hash))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.explorer
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: txs.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-primary",
								children: x.id
							}), x.zk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t.zk }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: x.chain.toUpperCase()
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm",
							children: [
								x.from,
								" → ",
								x.to
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								oxi(x.amount),
								" ",
								x.asset,
								" · ",
								t.fee,
								" ",
								oxi(x.fee, 4)
							]
						})
					]
				}, x.id))
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.bridges
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2 sm:grid-cols-4",
				children: [
					["BTC", "wrapped"],
					["ETH", "wrapped"],
					["SOL", "wrapped"],
					["BSC", "watch"]
				].map(([name, st]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg bg-secondary px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: st === "watch" ? t.watch : t.healthy
					})]
				}, name))
			})]
		})
	] });
}
//#endregion
export { Chain as component };
