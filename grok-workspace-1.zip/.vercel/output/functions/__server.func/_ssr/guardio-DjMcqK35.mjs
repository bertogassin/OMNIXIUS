import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as cityName, g as oxi, l as guards, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Dialog, o as DialogContent, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/guardio-DjMcqK35.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Guardio() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const dispatchGuard = usePlatform((s) => s.dispatchGuard);
	const contracts = usePlatform((s) => s.contracts).filter((c) => c.kind === "guard");
	const setStatus = usePlatform((s) => s.setContractStatus);
	const [box, setBox] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.field,
			title: t.guardio,
			lede: t.guardLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "grid gap-3 sm:grid-cols-2",
			children: guards.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: g.firm
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: cityName(g.cityId)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: g.available ? "success" : "muted",
						children: g.available ? t.available : t.busy
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						t.response,
						" ",
						g.responseMin,
						" ",
						t.min,
						" · ",
						g.units,
						" · ",
						g.armed ? t.armed : t.unarmed
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 font-display text-xl tabular-nums",
					children: [
						oxi(g.rateOxi, 0),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: t.oxi
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					className: "mt-4",
					onClick: () => {
						const res = dispatchGuard(g.id);
						if (res.ok) toast.success(res.free ? t.firstFree : t.dispatched);
						else toast.error(t.needClearance);
					},
					children: t.dispatch
				})
			] }) }, g.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.contracts
			}), contracts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: t.emptyContracts
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: contracts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-2 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: c.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							cityName(c.cityId),
							" · ",
							oxi(c.amount, 0),
							" ",
							t.oxi
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: c.status === "disputed" ? "danger" : "default",
							children: t[c.status]
						}), c.status === "in_field" || c.status === "locked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setBox(c.id),
							children: t.dispute
						}) : null]
					})]
				}, c.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!box,
			onOpenChange: (o) => !o && setBox(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				title: t.dispute,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "scanlines relative mt-4 overflow-hidden rounded-lg bg-secondary p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "type-kicker",
							children: t.stream
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-2xl",
							children: t.onSite
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: ["ZK · ", t.hidden]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-24 rounded-md bg-background/50 shadow-[var(--shadow-border)]" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => {
							if (box) setStatus(box, "resolved");
							setBox(null);
						},
						children: t.resolveA
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							if (box) setStatus(box, "resolved");
							setBox(null);
						},
						children: t.resolveB
					})]
				})]
			})
		})
	] });
}
//#endregion
export { Guardio as component };
