import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { g as oxi, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Input, r as Label, s as Button } from "./router-CCIKrNZI.mjs";
import { a as VerifBadge, i as Stat, n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
import { t as Segmented } from "./tabs-BjeX4hkk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/passport-DHTC0a8U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Passport() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const p = usePlatform((s) => s.passport);
	const contracts = usePlatform((s) => s.contracts);
	const setPassport = usePlatform((s) => s.setPassport);
	const setClearance = usePlatform((s) => s.setClearance);
	const setVerification = usePlatform((s) => s.setVerification);
	const resetDemo = usePlatform((s) => s.resetDemo);
	const [name, setName] = (0, import_react.useState)(p.name);
	const [handle, setHandle] = (0, import_react.useState)(p.handle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.people,
			title: t.passport,
			lede: t.passLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.trust,
					value: p.trust
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.oxi,
					value: oxi(p.oxi, 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.contracts,
					value: contracts.length
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "type-kicker",
					children: t.lattice
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t.latticeCopy
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifBadge, {
							v: p.verification,
							t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: p.clearance === "operator" ? t.operatorLong : p.clearance === "pro" ? t.proLong : t.citizenLong }),
						p.hasTools ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "success",
							children: t.withTools
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "muted",
							children: t.withoutTools
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 320 120",
					className: "mt-4 h-24 w-full text-primary",
					"aria-hidden": true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "40",
							cy: "60",
							r: "16",
							fill: "none",
							stroke: "currentColor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "160",
							cy: "60",
							r: "22",
							fill: "none",
							stroke: "currentColor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "280",
							cy: "60",
							r: "16",
							fill: "none",
							stroke: "currentColor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "56",
							y1: "60",
							x2: "138",
							y2: "60",
							stroke: "currentColor",
							strokeOpacity: "0.4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "182",
							y1: "60",
							x2: "264",
							y2: "60",
							stroke: "currentColor",
							strokeOpacity: "0.4"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: "40",
							y: "100",
							textAnchor: "middle",
							fill: "currentColor",
							style: { fontSize: 10 },
							children: "BOLH"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: "160",
							y: "100",
							textAnchor: "middle",
							fill: "currentColor",
							style: { fontSize: 10 },
							children: "PASSPORT"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
							x: "280",
							y: "100",
							textAnchor: "middle",
							fill: "currentColor",
							style: { fontSize: 10 },
							children: "VAULT"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-3 sm:grid-cols-2",
				onSubmit: (e) => {
					e.preventDefault();
					setPassport({
						name: name.trim() || p.name,
						handle: handle.replace(/^@/, "")
					});
					toast.success(t.saved);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "nm",
						children: t.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "nm",
						className: "mt-1",
						value: name,
						onChange: (e) => setName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "hd",
						children: t.handle
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "hd",
						className: "mt-1",
						value: handle,
						onChange: (e) => setHandle(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs text-muted",
							children: t.operatorLong
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
							value: p.clearance,
							onChange: (id) => setClearance(id),
							options: [
								{
									id: "citizen",
									label: t.citizenLong
								},
								{
									id: "pro",
									label: t.proLong
								},
								{
									id: "operator",
									label: t.operatorLong
								}
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs text-muted",
							children: t.credentialLong
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
							value: p.verification,
							onChange: (id) => setVerification(id),
							options: [
								{
									id: "none",
									label: t.none
								},
								{
									id: "identity",
									label: t.identityLong
								},
								{
									id: "credential",
									label: t.credentialLong
								}
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: p.hasTools,
							onChange: (e) => setPassport({ hasTools: e.target.checked })
						}), t.youHave]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: t.saveName
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t.contracts
				}),
				contracts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t.emptyContracts
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border",
					children: contracts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: t[c.status]
						})]
					}, c.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					className: "mt-4",
					onClick: () => {
						resetDemo();
						toast.success(t.restDone);
					},
					children: t.rest
				})
			]
		})
	] });
}
//#endregion
export { Passport as component };
