import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as ago, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Input, r as Label, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/repo-B8LhcP-C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Repo() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const files = usePlatform((s) => s.files);
	const uploadFile = usePlatform((s) => s.uploadFile);
	const [name, setName] = (0, import_react.useState)("note.pq");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.capital,
			title: t.repo,
			lede: t.repoLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-end",
			onSubmit: (e) => {
				e.preventDefault();
				uploadFile(name.trim() || "node.pq", 32 + Math.floor(Math.random() * 400));
				toast.success(t.uploaded);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "fn",
					children: t.fileName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "fn",
					className: "mt-1",
					value: name,
					onChange: (e) => setName(e.target.value)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: t.upload
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3",
			children: files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: f.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							f.sizeKb,
							" KB · ",
							ago(f.ts, locale)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [f.encrypted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t.encrypted }) : null, f.pqc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "success",
							children: t.pqc
						}) : null]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "type-kicker mt-4",
					children: t.shards
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex h-10 items-end gap-1",
					children: Array.from({ length: f.shards }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 rounded-sm bg-primary/70",
						style: { height: `${40 + i * 17 % 50}%` }
					}, i))
				})
			] }) }, f.id))
		})
	] });
}
//#endregion
export { Repo as component };
