import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as oxiSpark, g as oxi, o as cn, s as copy, u as isValentine, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Input, r as Label, s as Button } from "./router-CCIKrNZI.mjs";
import { i as Stat, n as ModuleHeader, r as Panel } from "./module-CzoTTlq0.mjs";
import { n as Area, r as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vault-BK5tCBLW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Switch({ checked, onCheckedChange, className, id }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		id,
		checked,
		onCheckedChange,
		className: cn("relative h-6 w-11 shrink-0 rounded-full bg-secondary shadow-[var(--shadow-border)] data-[state=checked]:bg-primary", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-0.5 rounded-full bg-foreground transition-transform duration-150 data-[state=checked]:translate-x-[1.35rem] data-[state=checked]:bg-primary-foreground" })
	});
}
function Vault() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const p = usePlatform((s) => s.passport);
	const valentineDemo = usePlatform((s) => s.valentineDemo);
	const setValentineDemo = usePlatform((s) => s.setValentineDemo);
	const sendTx = usePlatform((s) => s.sendTx);
	const [to, setTo] = (0, import_react.useState)("@nika");
	const [amount, setAmount] = (0, import_react.useState)("40");
	const [zk, setZk] = (0, import_react.useState)(true);
	const [chain, setChain] = (0, import_react.useState)("omni");
	const spark = oxiSpark.map((v, i) => ({
		i,
		v
	}));
	const valentine = isValentine(valentineDemo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.capital,
			title: t.vault,
			lede: t.vaultLede,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex h-11 items-center gap-2 text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: valentineDemo,
					onCheckedChange: setValentineDemo
				}), t.valentineOn]
			})
		}),
		valentine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-5 rounded-lg bg-secondary px-4 py-3 text-sm text-primary shadow-[var(--shadow-border)]",
			children: t.valentine
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "OXI",
					value: oxi(p.oxi, 0)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "WBTC",
					value: oxi(p.wbtc, 3)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "WETH",
					value: oxi(p.weth, 2)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "SOL",
					value: oxi(p.sol, 1)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "BNB",
					value: oxi(p.bnb, 0)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.spark
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-36",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaChart, {
						data: spark,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
							type: "monotone",
							dataKey: "v",
							stroke: "var(--color-primary)",
							fill: "color-mix(in oklab, var(--color-primary) 22%, transparent)",
							strokeWidth: 1.6
						})
					})
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.send
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				onSubmit: (e) => {
					e.preventDefault();
					const res = sendTx({
						to,
						amount: Number(amount),
						asset: "OXI",
						chain,
						zk
					});
					if (res.ok) toast.success(res.free ? t.firstFree : t.sent);
					else toast.error(t.needClearance);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "to",
						children: t.recipient
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "to",
						className: "mt-1",
						value: to,
						onChange: (e) => setTo(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "amt",
						children: t.amount
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "amt",
						className: "mt-1",
						type: "number",
						min: .01,
						step: "0.01",
						value: amount,
						onChange: (e) => setAmount(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t.chainLabel }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 h-11 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]",
						value: chain,
						onChange: (e) => setChain(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "omni",
								children: t.omni
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "btc",
								children: t.btc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "eth",
								children: t.eth
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "sol",
								children: t.sol
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "bsc",
								children: t.bsc
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center gap-2 self-end text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: zk,
								onChange: (e) => setZk(e.target.checked)
							}),
							t.zk,
							" · ",
							t.confidential
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: t.confirm
						})
					})
				]
			})]
		})
	] });
}
//#endregion
export { Vault as component };
