import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as ago, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel } from "./module-CzoTTlq0.mjs";
import { t as useAsk } from "./use-ask-BdvHF2yr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notepad-DrfPQlto.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Notepad() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const notes = usePlatform((s) => s.notes);
	const addNote = usePlatform((s) => s.addNote);
	const setNotePlan = usePlatform((s) => s.setNotePlan);
	const [raw, setRaw] = (0, import_react.useState)("");
	const { ask, pending } = useAsk();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.intel,
			title: t.notepad,
			lede: t.noteLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: async (e) => {
				e.preventDefault();
				if (!raw.trim()) return;
				const id = addNote(raw.trim());
				const res = await ask("notepad", raw.trim());
				if (res.ok) setNotePlan(id, res.text);
				else toast.error(t.aiDown);
				setRaw("");
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: raw,
				onChange: (e) => setRaw(e.target.value),
				placeholder: t.notePh
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-3",
				disabled: pending,
				children: pending ? t.thinking : t.plan
			})]
		}) }),
		notes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted",
			children: t.emptyNotes
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-3",
			children: notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: n.raw
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: ago(n.ts, locale)
				}),
				n.plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-muted",
					children: n.plan
				}) : null
			] }) }, n.id))
		})
	] });
}
//#endregion
export { Notepad as component };
