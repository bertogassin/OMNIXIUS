import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as cityName, n as ago, o as cn, p as mergePosts, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel } from "./module-CzoTTlq0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/nexus-Hx-2UuOo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Nexus() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const extraPosts = usePlatform((s) => s.extraPosts);
	const posts = mergePosts(extraPosts);
	const liked = usePlatform((s) => s.liked);
	const likePost = usePlatform((s) => s.likePost);
	const addPost = usePlatform((s) => s.addPost);
	const [body, setBody] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.people,
			title: t.nexus,
			lede: t.nexusLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (e) => {
				e.preventDefault();
				if (!body.trim()) return;
				addPost(body.trim());
				setBody("");
				toast.success(t.posted);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: body,
				onChange: (e) => setBody(e.target.value),
				placeholder: t.notePh
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-3",
				size: "sm",
				children: t.post
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-3",
			children: posts.map((p) => {
				const on = liked.includes(p.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed",
					children: locale === "ru" ? p.bodyRu : p.body
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between text-xs text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						p.author,
						" · ",
						cityName(p.cityId),
						" · ",
						ago(p.ts, locale)
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => likePost(p.id),
						className: cn("h-11 px-2", on && "text-primary"),
						children: [
							t.like,
							" ",
							p.likes + (on ? 1 : 0)
						]
					})]
				})] }) }, p.id);
			})
		})
	] });
}
//#endregion
export { Nexus as component };
