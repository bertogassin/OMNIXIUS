import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-BfolWrK0.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEMS = {
	mvs: `You are MVS, Minister of Foreign Affairs of the OMNIXIUS omni-platform.
You onboard people, translate, and give cautious market and logistics advice.
Never promise returns. Never invent prices or legal facts.
Citizen clearance: stay high-level. Operator clearance: you may discuss protocol, treasury risk, and threat context.
Reply in the user's language. No emoji. Short paragraphs. If giving advice, include one risk line.`,
	president: `You are President, the local guardian core of OMNIXIUS.
You watch state transitions, contracts, and threats.
You MUST NOT claim you can recompile or patch live binaries. You only propose policy/UI patches the operator must accept.
Structure: OBSERVED / RISK / ACTION. Reply in the user's language. No emoji. No theatrics.`,
	notepad: `You turn a raw note into a concrete plan for the OMNIXIUS operator.
Output: Goal, Steps (numbered), Blockers, Next 24h. Reply in the user's language. No emoji.`
};
var askAgent_createServerFn_handler = createServerRpc({
	id: "391a43e06ca8395ab64718a5009527a605f595d74947b6040b33ddaf781f63fe",
	name: "askAgent",
	filename: "src/lib/ai.ts"
}, (opts) => askAgent.__executeServer(opts));
var askAgent = createServerFn({ method: "POST" }).validator((input) => {
	const message = (input.message ?? "").trim().slice(0, 3e3);
	if (!message) throw new Error("empty");
	return {
		agent: input.agent === "president" || input.agent === "notepad" ? input.agent : "mvs",
		message,
		clearance: input.clearance.slice(0, 24),
		locale: input.locale === "en" ? "en" : "ru",
		history: (input.history ?? []).slice(-10).map((m) => ({
			role: m.role === "assistant" ? "assistant" : "user",
			content: m.content.slice(0, 2e3)
		}))
	};
}).handler(askAgent_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "unavailable"
	};
	const messages = [
		{
			role: "system",
			content: `${SYSTEMS[data.agent]}\nClearance: ${data.clearance}. Locale: ${data.locale}.`
		},
		...data.history,
		{
			role: "user",
			content: data.message
		}
	];
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			messages,
			max_tokens: 700,
			temperature: .4
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI ${res.status}`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "empty"
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { askAgent_createServerFn_handler };
