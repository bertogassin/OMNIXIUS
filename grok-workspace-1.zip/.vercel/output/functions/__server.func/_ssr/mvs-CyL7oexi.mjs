import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { o as cn, s as copy, v as uid, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as MvsSeal, i as Textarea, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel } from "./module-CzoTTlq0.mjs";
import { t as useAsk } from "./use-ask-BdvHF2yr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mvs-CyL7oexi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Mvs() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const messages = usePlatform((s) => s.mvs);
	const pushMvs = usePlatform((s) => s.pushMvs);
	const [text, setText] = (0, import_react.useState)("");
	const { ask, pending } = useAsk();
	const end = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
		kicker: t.intel,
		title: t.mvs,
		lede: t.mvsLede,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MvsSeal, {
			className: "size-12",
			live: true
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "flex min-h-[28rem] flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 space-y-3 overflow-y-auto",
			children: [messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t.emptyChat
			}) : messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("max-w-[42rem] rounded-lg px-3 py-2 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-secondary" : "bg-background shadow-[var(--shadow-border)]"),
				children: m.text
			}, m.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: end })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4",
			onSubmit: async (e) => {
				e.preventDefault();
				const msg = text.trim();
				if (!msg) return;
				setText("");
				pushMvs({
					id: uid("m"),
					role: "user",
					text: msg,
					ts: Date.now()
				});
				const history = [...messages, {
					role: "user",
					text: msg
				}].slice(-10).map((m) => ({
					role: m.role,
					content: m.text
				}));
				const res = await ask("mvs", msg, history);
				if (res.ok) pushMvs({
					id: uid("m"),
					role: "assistant",
					text: res.text,
					ts: Date.now()
				});
				else toast.error(t.aiDown);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: text,
				onChange: (e) => setText(e.target.value),
				placeholder: t.mvsPh
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "mt-3",
				disabled: pending,
				children: pending ? t.thinking : t.send
			})]
		})]
	})] });
}
//#endregion
export { Mvs as component };
