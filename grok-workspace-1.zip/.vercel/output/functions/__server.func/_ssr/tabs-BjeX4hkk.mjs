import { o as cn } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tabs-BjeX4hkk.js
var import_jsx_runtime = require_jsx_runtime();
function Segmented({ value, onChange, options, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-wrap gap-1 rounded-lg bg-secondary p-1", className),
		role: "tablist",
		children: options.map((o) => {
			const on = o.id === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "tab",
				"aria-selected": on,
				onClick: () => onChange(o.id),
				className: cn("h-9 min-h-9 rounded-md px-3 text-xs font-medium tracking-wide transition-colors duration-150", on ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted hover:text-foreground"),
				children: o.label
			}, o.id);
		})
	});
}
//#endregion
export { Segmented as t };
