import { a as cityName, c as experts, g as oxi, m as mergeTxs, n as ago, p as mergePosts, s as copy, u as isValentine, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as MvsSeal, l as PresidentSeal } from "./router-CCIKrNZI.mjs";
import { i as Stat, n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-oJZ3snWn.js
var import_jsx_runtime = require_jsx_runtime();
function Deck() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const passport = usePlatform((s) => s.passport);
	const blocks = usePlatform((s) => s.blocks);
	const contracts = usePlatform((s) => s.contracts);
	const valentineDemo = usePlatform((s) => s.valentineDemo);
	const threats = usePlatform((s) => s.threats);
	const extraPosts = usePlatform((s) => s.extraPosts);
	const extraTxs = usePlatform((s) => s.extraTxs);
	const height = blocks[blocks.length - 1]?.height ?? 0;
	const valentine = isValentine(valentineDemo);
	const nearby = experts.filter((e) => e.available).slice(0, 4);
	const open = threats.filter((x) => x.status === "open");
	const posts = mergePosts(extraPosts).slice(0, 4);
	const txs = mergeTxs(extraTxs).slice(0, 4);
	const spine = [...posts.map((p) => ({
		ts: p.ts,
		kind: "post",
		p
	})), ...txs.map((x) => ({
		ts: x.ts,
		kind: "tx",
		x
	}))].sort((a, b) => b.ts - a.ts).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.kicker,
			title: t.deck,
			lede: t.deckLede
		}),
		valentine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-5 rounded-lg bg-secondary px-4 py-3 text-sm text-primary shadow-[var(--shadow-border)]",
			children: t.valentine
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.height,
					value: height.toLocaleString(),
					hint: t.pqc
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.oxi,
					value: oxi(passport.oxi, 0),
					hint: t.peersN
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.trust,
					value: passport.trust,
					hint: t.lattice
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: t.threats,
					value: open.length,
					hint: open.some((x) => x.level === "critical") ? t.critical : t.healthy
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-3 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresidentSeal, {
						className: "size-10",
						live: open.length > 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "type-kicker",
						children: t.president
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: open.length ? t.presidentAlert : t.presidentIdle
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/president",
						className: "ml-auto text-sm text-primary",
						children: t.continue
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MvsSeal, {
						className: "size-10",
						live: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "type-kicker",
						children: t.mvs
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: t.mvsIdle
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/mvs",
						className: "ml-auto text-sm text-primary",
						children: t.mvsOpen
					})
				]
			}) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 grid gap-3 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "type-kicker",
					children: t.live
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border",
					children: spine.map((row) => row.kind === "post" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "flex min-h-14 items-start justify-between gap-3 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: locale === "ru" ? row.p.bodyRu : row.p.body
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted",
							children: [
								row.p.author,
								" · ",
								cityName(row.p.cityId),
								" · ",
								ago(row.p.ts, locale)
							]
						})] })
					}, row.p.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex min-h-14 items-start justify-between gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-primary",
							children: row.x.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm",
							children: [
								row.x.from,
								" → ",
								row.x.to,
								" · ",
								oxi(row.x.amount),
								" ",
								row.x.asset
							]
						})] }), row.x.zk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t.zk }) : null]
					}, row.x.id))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "self-start",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "type-kicker",
						children: t.nearby
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-3",
						children: nearby.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/map",
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: e.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									locale === "ru" ? e.craftRu : e.craft,
									" · ",
									cityName(e.cityId)
								]
							})]
						}) }, e.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "type-kicker mt-6",
						children: t.contracts
					}),
					contracts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t.emptyContracts
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-2",
						children: contracts.slice(0, 3).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-sm",
							children: [
								c.title,
								" · ",
								t[c.status]
							]
						}, c.id))
					})
				]
			})]
		})
	] });
}
//#endregion
export { Deck as component };
