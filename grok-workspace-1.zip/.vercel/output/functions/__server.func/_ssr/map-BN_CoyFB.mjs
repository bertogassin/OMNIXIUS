import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as cityName, c as experts, g as oxi, i as cities, o as cn, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { s as Button } from "./router-CCIKrNZI.mjs";
import { a as VerifBadge, n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
import { t as Segmented } from "./tabs-BjeX4hkk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/map-BN_CoyFB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function fit(userHas, proHas, filter) {
	if (filter === "need-tools" && !proHas) return "blocked";
	if (filter === "have-tools" && proHas) return "redundant";
	if (!userHas && !proHas) return "blocked";
	if (!userHas && proHas) return "optimal";
	if (userHas && proHas) return "redundant";
	return "ok";
}
function MapPage() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const selected = usePlatform((s) => s.selectedCityId);
	const setSelectedCity = usePlatform((s) => s.setSelectedCity);
	const logistics = usePlatform((s) => s.logistics);
	const setLogistics = usePlatform((s) => s.setLogistics);
	const hasTools = usePlatform((s) => s.passport.hasTools);
	const lockExpert = usePlatform((s) => s.lockExpert);
	const theatre = cities.find((c) => c.id === selected)?.theatre ?? "europe";
	const theatreCities = cities.filter((c) => c.theatre === theatre);
	const shown = (0, import_react.useMemo)(() => {
		return experts.filter((e) => {
			const city = cities.find((c) => c.id === e.cityId);
			if (!city || city.theatre !== theatre) return false;
			if (selected && e.cityId !== selected) return true;
			return true;
		}).filter((e) => theatreCities.some((c) => c.id === e.cityId));
	}, [
		theatre,
		selected,
		theatreCities
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.field,
			title: t.map,
			lede: t.mapLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			value: theatre,
			onChange: (id) => {
				const first = cities.find((c) => c.theatre === id);
				setSelectedCity(first?.id ?? null);
			},
			options: [
				{
					id: "europe",
					label: t.europe
				},
				{
					id: "africa",
					label: t.africa
				},
				{
					id: "asia",
					label: t.asia
				},
				{
					id: "americas",
					label: t.americas
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex flex-wrap gap-2",
			children: [
				["any", t.toolsAny],
				["need-tools", t.youNeed],
				["have-tools", t.youHave]
			].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: logistics === id ? "default" : "outline",
				onClick: () => setLogistics(id),
				children: label
			}, id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
			className: "mt-4 overflow-hidden p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartograph, {
				theatre,
				selected,
				onSelect: setSelectedCity
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3 lg:grid-cols-2",
			children: shown.map((e) => {
				const f = fit(hasTools, e.hasTools, logistics);
				const blocked = f === "blocked" || e.verification !== "credential";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: cn(selected === e.cityId && "shadow-[var(--shadow-border-hover)]"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: e.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									locale === "ru" ? e.craftRu : e.craft,
									" · ",
									cityName(e.cityId)
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerifBadge, {
								v: e.verification,
								t
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: locale === "ru" ? e.bioRu : e.bio
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap items-center gap-2 text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: e.hasTools ? "success" : "muted",
									children: e.hasTools ? t.withTools : t.withoutTools
								}),
								f === "optimal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "success",
									children: t.optimal
								}) : null,
								f === "redundant" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "warn",
									children: t.redundant
								}) : null,
								f === "blocked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "danger",
									children: t.blocked
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [
										oxi(e.rateOxi, 0),
										" ",
										t.oxi
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									e.rating,
									" · ",
									e.reviews
								] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								disabled: blocked,
								onClick: () => {
									if (e.verification !== "credential") {
										toast.error(t.offerBlocked);
										return;
									}
									const res = lockExpert(e.id, 2);
									if (res.ok) toast.success(res.free ? t.firstFree : t.lockedOk);
									else toast.error(t.needClearance);
								},
								children: t.lock
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setSelectedCity(e.cityId),
								children: t.dest
							})]
						}),
						e.verification !== "credential" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-destructive",
							children: t.offerBlocked
						}) : null
					]
				}) }, e.id);
			})
		})
	] });
}
function Cartograph({ theatre, selected, onSelect }) {
	const pts = cities.filter((c) => c.theatre === theatre);
	const lats = pts.map((p) => p.lat);
	const lngs = pts.map((p) => p.lng);
	const minLat = Math.min(...lats) - 8;
	const maxLat = Math.max(...lats) + 8;
	const minLng = Math.min(...lngs) - 12;
	const maxLng = Math.max(...lngs) + 12;
	function xy(lat, lng) {
		return {
			x: (lng - minLng) / (maxLng - minLng) * 1e3,
			y: (maxLat - lat) / (maxLat - minLat) * 420
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 1000 420",
		className: "h-auto w-full text-primary",
		role: "img",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "1000",
				height: "420",
				fill: "var(--color-card)"
			}),
			Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: (i + 1) * 110,
				y1: "0",
				x2: (i + 1) * 110,
				y2: "420",
				stroke: "currentColor",
				strokeOpacity: "0.06"
			}, `v${i}`)),
			Array.from({ length: 5 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "0",
				y1: (i + 1) * 70,
				x2: "1000",
				y2: (i + 1) * 70,
				stroke: "currentColor",
				strokeOpacity: "0.06"
			}, `h${i}`)),
			pts.map((c) => {
				const { x, y } = xy(c.lat, c.lng);
				const on = c.id === selected;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					transform: `translate(${x},${y})`,
					className: "cursor-pointer",
					onClick: () => onSelect(c.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						r: on ? 8 : 5,
						fill: on ? "currentColor" : "none",
						stroke: "currentColor",
						strokeWidth: "1.4"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						y: "22",
						textAnchor: "middle",
						fill: "currentColor",
						style: {
							fontSize: 13,
							fontFamily: "Outfit, sans-serif"
						},
						children: c.name
					})]
				}, c.id);
			})
		]
	});
}
//#endregion
export { MapPage as component };
