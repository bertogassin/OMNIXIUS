import { i as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as experts, d as listings, h as openThreats, i as cities, l as guards, o as cn, r as bearingTo, s as copy, t as HOME, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Shield, c as PenLine, d as LayoutGrid, f as Fingerprint, g as Boxes, h as Compass, i as Store, l as MessagesSquare, m as Database, n as Wallet, o as Search, p as Eye, r as TriangleAlert, s as Radio, t as X, u as Menu } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, t as Dialog$1, u as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CCIKrNZI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-destructive",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-lg font-medium",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function OmniSeal({ className, live = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: cn("text-primary", live && "seal-live", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "30",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.35",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "22",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.5",
				strokeWidth: "0.8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 6 L35 24 L32 22 L29 24 Z M58 32 L40 35 L42 32 L40 29 Z M32 58 L29 40 L32 42 L35 40 Z M6 32 L24 29 L22 32 L24 35 Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "3.2",
				fill: "currentColor"
			})
		]
	});
}
function PresidentSeal({ className, live = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: cn(live ? "text-destructive seal-live" : "text-muted", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "14",
				width: "44",
				height: "36",
				rx: "4",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "8",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "2.5",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 50 L32 44 L42 50",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			})
		]
	});
}
function MvsSeal({ className, live = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: cn(live ? "text-primary seal-live" : "text-muted", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "20",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4",
				strokeDasharray: "4 3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 32 H46 M32 18 V46",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "4",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-40 [&_svg]:size-4 [&_svg]:shrink-0 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			outline: "hairline bg-transparent text-foreground hover:bg-secondary",
			ghost: "text-foreground hover:bg-secondary",
			danger: "bg-destructive text-foreground hover:bg-destructive/90",
			subtle: "bg-secondary text-foreground hover:bg-card-hover"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(92vw,32rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-card p-5 shadow-[var(--shadow-border-hover)]", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0 data-[state=open]:zoom-in-95 data-[state=closed]:zoom-out-95", className),
		children: [
			title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-xl font-medium tracking-tight",
				children: title
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "sr-only",
				children: "Dialog"
			}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "absolute top-3 right-3 size-11 text-muted hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mx-auto size-4" })
			})
		]
	})] });
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-secondary px-3 text-sm text-foreground shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-28 w-full rounded-lg bg-secondary px-3 py-2.5 text-sm text-foreground shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium tracking-wide text-muted", className),
		...props
	});
}
var Sheet = Dialog$1;
function SheetContent({ className, children, side = "right", title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed z-50 bg-card shadow-[var(--shadow-border-hover)]", side === "right" && "inset-y-0 right-0 h-full w-[min(100%,22rem)] rounded-l-xl p-5", side === "left" && "inset-y-0 left-0 h-full w-[min(100%,18rem)] rounded-r-xl p-5", side === "bottom" && "inset-x-0 bottom-0 max-h-[80vh] rounded-t-xl p-5", className),
		children: [
			title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-lg",
				children: title
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "sr-only",
				children: "Panel"
			}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "absolute top-3 right-3 size-11 text-muted hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mx-auto size-4" })
			})
		]
	})] });
}
var NAV = [
	{
		to: "/",
		key: "deck",
		icon: LayoutGrid,
		group: "deck"
	},
	{
		to: "/map",
		key: "map",
		icon: Compass,
		group: "field"
	},
	{
		to: "/agora",
		key: "agora",
		icon: Store,
		group: "field"
	},
	{
		to: "/guardio",
		key: "guardio",
		icon: Shield,
		group: "field"
	},
	{
		to: "/vault",
		key: "vault",
		icon: Wallet,
		group: "capital"
	},
	{
		to: "/chain",
		key: "chain",
		icon: Boxes,
		group: "capital"
	},
	{
		to: "/repo",
		key: "repo",
		icon: Database,
		group: "capital"
	},
	{
		to: "/nexus",
		key: "nexus",
		icon: Radio,
		group: "people"
	},
	{
		to: "/passport",
		key: "passport",
		icon: Fingerprint,
		group: "people"
	},
	{
		to: "/notepad",
		key: "notepad",
		icon: PenLine,
		group: "intel"
	},
	{
		to: "/mvs",
		key: "mvs",
		icon: MessagesSquare,
		group: "intel"
	},
	{
		to: "/president",
		key: "president",
		icon: Eye,
		group: "intel"
	}
];
var PRIMARY = [
	"/",
	"/map",
	"/agora",
	"/guardio"
];
function AppShell() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const hydrated = usePlatform((s) => s.hydrated);
	const bootSeen = usePlatform((s) => s.bootSeen);
	const hydrate = usePlatform((s) => s.hydrate);
	const tickChain = usePlatform((s) => s.tickChain);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => tickChain(), 8e3);
		return () => window.clearInterval(id);
	}, [tickChain]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, { force: true });
	if (!bootSeen) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-card focus:px-3 focus:py-2",
				children: "Skip"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex min-h-dvh max-w-[1440px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopNav, { t }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, { t }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						id: "main",
						className: "flex-1 px-4 py-5 pb-28 sm:px-6 lg:px-8 lg:pb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileNav, { t }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompassFab, { t }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { className: "!bg-card !text-foreground !border-border !shadow-[var(--shadow-border)]" }
			})
		]
	});
}
function BootScreen({ force }) {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const setBootSeen = usePlatform((s) => s.setBootSeen);
	const setLocale = usePlatform((s) => s.setLocale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col items-center justify-center bg-background px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "boot-stagger flex max-w-md flex-col items-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OmniSeal, {
					className: "size-16",
					live: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "type-kicker mt-8",
					children: t.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl font-medium tracking-tight sm:text-6xl",
					children: t.app
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: t.bootA
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-subtle",
					children: t.bootB
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 max-w-sm text-sm leading-relaxed text-muted",
					children: t.watchword
				}),
				!force ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-wrap items-center justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setBootSeen(),
						children: t.enter
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setLocale(locale === "ru" ? "en" : "ru"),
						children: t.lang
					})]
				}) : null
			]
		})
	});
}
function TopBar({ t }) {
	const setLocale = usePlatform((s) => s.setLocale);
	const locale = usePlatform((s) => s.locale);
	const passport = usePlatform((s) => s.passport);
	const threats = usePlatform((s) => openThreats(s).length);
	const [cmd, setCmd] = (0, import_react.useState)(false);
	const [more, setMore] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				setCmd(true);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-30 flex h-14 items-center gap-2 border-b border-border bg-background/90 px-4 backdrop-blur-sm sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-2 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OmniSeal, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-lg tracking-tight",
					children: "OMNIXIUS"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setCmd(true),
				className: "ml-auto hidden h-10 min-w-48 items-center gap-2 rounded-md bg-secondary px-3 text-left text-sm text-muted shadow-[var(--shadow-border)] md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" }),
					t.search,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-auto text-xs tracking-wide text-subtle",
						children: t.commandHint
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "ml-auto md:hidden",
				onClick: () => setCmd(true),
				"aria-label": t.search,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => setLocale(locale === "ru" ? "en" : "ru"),
				children: t.lang
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SosButton, { t }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/passport",
				className: "hidden h-10 items-center gap-2 rounded-md px-2 text-xs text-muted hover:bg-secondary sm:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-foreground",
						children: passport.trust
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: passport.clearance === "operator" ? t.operator : passport.clearance === "pro" ? t.pro : t.citizen }),
					threats > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-destructive pulse-dot" }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "lg:hidden",
				onClick: () => setMore(true),
				"aria-label": t.more,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandDialog, {
				open: cmd,
				onOpenChange: setCmd,
				t
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: more,
				onOpenChange: setMore,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					side: "bottom",
					title: t.modules,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-4 grid grid-cols-3 gap-2 pb-4",
						children: NAV.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: n.to,
							onClick: () => setMore(false),
							className: "flex min-h-14 flex-col items-center justify-center gap-1 rounded-lg bg-secondary text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(n.icon, { className: "size-4" }), t[n.key]]
						}, n.to))
					})
				})
			})
		]
	});
}
function DesktopNav({ t }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const threats = usePlatform((s) => openThreats(s).length);
	const groups = [
		{
			id: "deck",
			label: t.deck
		},
		{
			id: "field",
			label: t.field
		},
		{
			id: "capital",
			label: t.capital
		},
		{
			id: "people",
			label: t.people
		},
		{
			id: "intel",
			label: t.intel
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-3 py-5 lg:flex",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "mb-8 flex items-center gap-2 px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OmniSeal, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl tracking-tight",
					children: "OMNIXIUS"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex flex-1 flex-col gap-5 overflow-y-auto",
				children: groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [g.id !== "deck" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "type-kicker mb-2 px-2",
					children: g.label
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-0.5",
					children: NAV.filter((n) => n.group === g.id).map((n) => {
						const on = pathname === n.to;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: n.to,
							className: cn("flex h-11 items-center gap-2 rounded-md px-2 text-sm transition-colors duration-150", on ? "bg-secondary text-foreground" : "text-muted hover:bg-secondary/60 hover:text-foreground"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(n.icon, { className: "size-4" }),
								t[n.key],
								n.key === "president" && threats > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ml-auto size-1.5 rounded-full bg-destructive pulse-dot" }) : null
							]
						}) }, n.to);
					})
				})] }, g.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center gap-3 px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PresidentSeal, {
					className: "size-8",
					live: threats > 0
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MvsSeal, {
					className: "size-8",
					live: true
				})]
			})
		]
	});
}
function MobileNav({ t }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const items = NAV.filter((n) => PRIMARY.includes(n.to));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background/95 px-2 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm lg:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mx-auto flex h-16 max-w-lg items-stretch",
			children: items.map((n) => {
				const on = pathname === n.to;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: n.to,
						className: cn("flex h-full min-h-11 flex-col items-center justify-center gap-1 text-[0.6875rem] tracking-wide", on ? "text-foreground" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(n.icon, { className: "size-4" }), t[n.key]]
					})
				}, n.to);
			})
		})
	});
}
function SosButton({ t }) {
	const dispatchGuard = usePlatform((s) => s.dispatchGuard);
	const cityId = usePlatform((s) => s.selectedCityId) ?? "zurich";
	const onSos = () => {
		const g = guards.filter((g) => g.cityId === cityId && g.available)[0] ?? guards[0];
		if (dispatchGuard(g.id, true).ok) toast.success(t.sosSent);
		else toast.error(t.needClearance);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "danger",
		size: "sm",
		onClick: onSos,
		children: t.sos
	});
}
function CompassFab({ t }) {
	const cityId = usePlatform((s) => s.selectedCityId);
	const city = cities.find((c) => c.id === cityId);
	const deg = city ? bearingTo(HOME, city) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/map",
		"aria-label": t.compass,
		className: "fixed right-4 bottom-20 z-20 hidden size-16 items-center justify-center rounded-full bg-card shadow-[var(--shadow-border-hover)] sm:flex lg:bottom-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 80 80",
			className: "size-14 text-primary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "compass-ring",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "40",
					cy: "40",
					r: "34",
					fill: "none",
					stroke: "currentColor",
					strokeOpacity: "0.35"
				}), Array.from({ length: 12 }, (_, i) => {
					const a = i * 30 * Math.PI / 180;
					const x1 = 40 + Math.cos(a) * 28;
					const y1 = 40 + Math.sin(a) * 28;
					const x2 = 40 + Math.cos(a) * 32;
					const y2 = 40 + Math.sin(a) * 32;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1,
						y1,
						x2,
						y2,
						stroke: "currentColor",
						strokeWidth: "1"
					}, i);
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				style: {
					transform: `rotate(${deg}deg)`,
					transformOrigin: "40px 40px"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "40,14 44,40 40,36 36,40",
					fill: "currentColor"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "40,66 36,40 40,44 44,40",
					fill: "currentColor",
					fillOpacity: "0.35"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: city ? `${t.dest} ${city.name}` : t.noDest
		})]
	});
}
function CommandDialog({ open, onOpenChange, t }) {
	const [q, setQ] = (0, import_react.useState)("");
	const locale = usePlatform((s) => s.locale);
	const items = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		const mods = NAV.map((n) => ({
			id: n.to,
			to: n.to,
			label: t[n.key],
			hint: t.modules
		}));
		const people = experts.map((e) => ({
			id: e.id,
			to: "/map",
			label: e.name,
			hint: locale === "ru" ? e.craftRu : e.craft
		}));
		const lots = listings.map((l) => ({
			id: l.id,
			to: "/agora",
			label: locale === "ru" ? l.titleRu : l.title,
			hint: t.listings
		}));
		const all = [
			...mods,
			...people,
			...lots
		];
		if (!s) return all.slice(0, 12);
		return all.filter((i) => `${i.label} ${i.hint}`.toLowerCase().includes(s)).slice(0, 16);
	}, [
		q,
		t,
		locale
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			title: t.search,
			className: "p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				autoFocus: true,
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t.search,
				className: "mt-3"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 max-h-80 overflow-y-auto",
				children: items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-2 py-6 text-center text-sm text-muted",
					children: t.noResults
				}) : items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: i.to,
					onClick: () => onOpenChange(false),
					className: "flex min-h-11 items-center justify-between rounded-md px-2 text-sm hover:bg-secondary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: i.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: i.hint
					})]
				}) }, i.id))
			})]
		})
	});
}
var styles_default = "/assets/styles-CiZDsJds.css";
var APP_NAME = "OMNIXIUS";
var Route$12 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c0c0b"
			},
			{
				name: "description",
				content: "OMNIXIUS — sovereign bureau of the omni-platform."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,400;6..72,500;6..72,600&family=Outfit:wght@400;500;600&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$11 = () => import("./routes-oJZ3snWn.mjs");
var Route$11 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./agora-DZgFzYne.mjs");
var Route$10 = createFileRoute("/agora")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./chain-DuXktmdk.mjs");
var Route$9 = createFileRoute("/chain")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./guardio-DjMcqK35.mjs");
var Route$8 = createFileRoute("/guardio")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./map-BN_CoyFB.mjs");
var Route$7 = createFileRoute("/map")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./mvs-CyL7oexi.mjs");
var Route$6 = createFileRoute("/mvs")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./nexus-Hx-2UuOo.mjs");
var Route$5 = createFileRoute("/nexus")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./notepad-DrfPQlto.mjs");
var Route$4 = createFileRoute("/notepad")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./passport-DHTC0a8U.mjs");
var Route$3 = createFileRoute("/passport")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./president-BqUICWaR.mjs");
var Route$2 = createFileRoute("/president")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./repo-B8LhcP-C.mjs");
var Route$1 = createFileRoute("/repo")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./vault-BK5tCBLW.mjs");
var Route = createFileRoute("/vault")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$11.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$12
	}),
	AgoraRoute: Route$10.update({
		id: "/agora",
		path: "/agora",
		getParentRoute: () => Route$12
	}),
	ChainRoute: Route$9.update({
		id: "/chain",
		path: "/chain",
		getParentRoute: () => Route$12
	}),
	GuardioRoute: Route$8.update({
		id: "/guardio",
		path: "/guardio",
		getParentRoute: () => Route$12
	}),
	MapRoute: Route$7.update({
		id: "/map",
		path: "/map",
		getParentRoute: () => Route$12
	}),
	MvsRoute: Route$6.update({
		id: "/mvs",
		path: "/mvs",
		getParentRoute: () => Route$12
	}),
	NexusRoute: Route$5.update({
		id: "/nexus",
		path: "/nexus",
		getParentRoute: () => Route$12
	}),
	NotepadRoute: Route$4.update({
		id: "/notepad",
		path: "/notepad",
		getParentRoute: () => Route$12
	}),
	PassportRoute: Route$3.update({
		id: "/passport",
		path: "/passport",
		getParentRoute: () => Route$12
	}),
	PresidentRoute: Route$2.update({
		id: "/president",
		path: "/president",
		getParentRoute: () => Route$12
	}),
	RepoRoute: Route$1.update({
		id: "/repo",
		path: "/repo",
		getParentRoute: () => Route$12
	}),
	VaultRoute: Route.update({
		id: "/vault",
		path: "/vault",
		getParentRoute: () => Route$12
	})
};
var routeTree = Route$12._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { Dialog as a, MvsSeal as c, Textarea as i, PresidentSeal as l, Input as n, DialogContent as o, Label as r, Button as s, router_exports as t };
