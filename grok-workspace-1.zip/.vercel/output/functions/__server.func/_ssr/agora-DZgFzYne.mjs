import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as cityName, f as mergeListings, g as oxi, i as cities, s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Input, r as Label, s as Button } from "./router-CCIKrNZI.mjs";
import { n as ModuleHeader, r as Panel, t as Badge } from "./module-CzoTTlq0.mjs";
import { t as Segmented } from "./tabs-BjeX4hkk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/agora-DZgFzYne.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Agora() {
	const locale = usePlatform((s) => s.locale);
	const t = copy(locale);
	const kind = usePlatform((s) => s.listingKind);
	const setListingKind = usePlatform((s) => s.setListingKind);
	const extraListings = usePlatform((s) => s.extraListings);
	const lots = mergeListings(extraListings).filter((l) => kind === "all" || l.kind === kind);
	const lockListing = usePlatform((s) => s.lockListing);
	const addListing = usePlatform((s) => s.addListing);
	const setSelectedCity = usePlatform((s) => s.setSelectedCity);
	const [title, setTitle] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("400");
	const [cityId, setCityId] = (0, import_react.useState)("zurich");
	const [lotKind, setLotKind] = (0, import_react.useState)("goods");
	const [hidden, setHidden] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleHeader, {
			kicker: t.field,
			title: t.agora,
			lede: t.agoraLede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
			value: kind,
			onChange: (id) => setListingKind(id),
			options: [
				{
					id: "all",
					label: t.all
				},
				{
					id: "goods",
					label: t.goods
				},
				{
					id: "land",
					label: t.land
				},
				{
					id: "auto",
					label: t.auto
				},
				{
					id: "service",
					label: t.service
				}
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-3 sm:grid-cols-2",
			children: lots.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: locale === "ru" ? l.titleRu : l.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							t[l.kind],
							" · ",
							cityName(l.cityId),
							" · ",
							l.seller
						]
					})] }), l.hiddenRoute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: t.hidden }) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: locale === "ru" ? l.blurbRu : l.blurb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-display text-2xl tabular-nums",
					children: [
						oxi(l.priceOxi, 0),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: t.oxi
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => {
							const res = lockListing(l.id);
							if (res.ok) {
								toast.success(res.free ? t.firstFree : t.lockedOk);
								setSelectedCity(l.cityId);
							} else toast.error(t.needClearance);
						},
						children: l.kind === "land" ? t.lease : t.buy
					})
				})
			] }) }, l.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "type-kicker",
				children: t.newListing
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				onSubmit: (e) => {
					e.preventDefault();
					if (!addListing({
						title: title.trim(),
						kind: lotKind,
						priceOxi: Number(price) || 0,
						cityId,
						hiddenRoute: hidden
					}).ok) toast.error(t.offerBlocked);
					else {
						toast.success(t.posted);
						setTitle("");
					}
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "lot-title",
							children: t.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "lot-title",
							className: "mt-1",
							value: title,
							onChange: (e) => setTitle(e.target.value),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "lot-price",
						children: t.price
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "lot-price",
						className: "mt-1",
						type: "number",
						min: 1,
						value: price,
						onChange: (e) => setPrice(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "lot-city",
						children: t.city
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "lot-city",
						className: "mt-1 h-11 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]",
						value: cityId,
						onChange: (e) => setCityId(e.target.value),
						children: cities.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: t.kind }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 h-11 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]",
						value: lotKind,
						onChange: (e) => setLotKind(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "goods",
								children: t.goods
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "land",
								children: t.land
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "auto",
								children: t.auto
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "service",
								children: t.service
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: hidden,
							onChange: (e) => setHidden(e.target.checked)
						}), t.confidential]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: t.publishLot
						})
					})
				]
			})]
		})
	] });
}
//#endregion
export { Agora as component };
