import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { s as copy, y as usePlatform } from "./store-BrNzYY9P.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-ask-BdvHF2yr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askAgent = createServerFn({ method: "POST" }).validator((input) => {
	const message = (input.message ?? "").trim().slice(0, 3e3);
	if (!message) throw new Error("empty");
	return {
		agent: input.agent === "president" || input.agent === "notepad" ? input.agent : "mvs",
		message,
		clearance: input.clearance.slice(0, 24),
		locale: input.locale === "en" ? "en" : "ru",
		history: (input.history ?? []).slice(-10).map((m) => ({
			role: m.role === "assistant" ? "assistant" : "user",
			content: m.content.slice(0, 2e3)
		}))
	};
}).handler(createSsrRpc("391a43e06ca8395ab64718a5009527a605f595d74947b6040b33ddaf781f63fe"));
function useAsk() {
	const [pending, setPending] = (0, import_react.useState)(false);
	const locale = usePlatform((s) => s.locale);
	const clearance = usePlatform((s) => s.passport.clearance);
	const t = copy(locale);
	async function ask(agent, message, history) {
		setPending(true);
		try {
			const res = await askAgent({ data: {
				agent,
				message,
				clearance,
				locale,
				history
			} });
			if (!res.ok) return {
				ok: false,
				error: t.aiDown
			};
			return res;
		} catch {
			return {
				ok: false,
				error: t.aiDown
			};
		} finally {
			setPending(false);
		}
	}
	return {
		ask,
		pending,
		t
	};
}
//#endregion
export { useAsk as t };
